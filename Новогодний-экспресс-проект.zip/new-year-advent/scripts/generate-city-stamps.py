#!/usr/bin/env python3
"""Generate 41 original illustrated SVG postage stamps for the New Year Express route."""
from __future__ import annotations

import html
import re
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STAMP_DIR = ROOT / "stamps"
ROUTE_FILE = ROOT / "route.js"

# One simple, recognisable local storybook landmark per stop.
MOTIFS = {
    1: "moscow_kremlin", 2: "sergiev_cathedral", 3: "yaroslavl_bear",
    4: "kostroma_terem", 5: "vologda_lace", 6: "arkhangelsk_harbor",
    7: "murmansk_aurora", 8: "petrozavodsk_lake_church", 9: "vyborg_castle",
    10: "petersburg_bridge_spire", 11: "novgorod_bell", 12: "pskov_wall",
    13: "kaliningrad_amber_lighthouse", 14: "smolensk_fortress", 15: "tver_bridge",
    16: "tula_gingerbread", 17: "ryazan_cathedral", 18: "nizhny_confluence",
    19: "kazan_mosque", 20: "samara_rocket", 21: "ufa_honey_hills",
    22: "perm_bear_bridge", 23: "yekaterinburg_arch", 24: "tyumen_hot_springs",
    25: "tobolsk_white_kremlin", 26: "omsk_ice_bridge", 27: "novosibirsk_opera",
    28: "krasnoyarsk_stolby", 29: "irkutsk_baikal_house", 30: "ulanude_datsan",
    31: "yakutsk_ice_city", 32: "magadan_lighthouse", 33: "kamchatka_volcanoes",
    34: "sakhalin_cable_mountain", 35: "khabarovsk_amur_bridge", 36: "vladivostok_golden_bridge",
    37: "sochi_sea_mountain", 38: "rostov_don_bridge", 39: "volgograd_star",
    40: "suzdal_domes", 41: "ustyug_fairytale_house",
}

PALETTES = [
    ("#aa3738", "#64acd0", "#f5cb68", "#3d7650"),
    ("#246448", "#82c4dc", "#ffd776", "#c85543"),
    ("#3e5c8e", "#9bd2e1", "#f2bf56", "#a74245"),
    ("#b94a3d", "#89c2d9", "#ffe08a", "#47865d"),
    ("#35664c", "#8dcadd", "#f5b849", "#b74647"),
    ("#9e632e", "#83bdd8", "#ffdc79", "#3b7656"),
    ("#275c72", "#a1d9e3", "#f8ca68", "#bc4f47"),
    ("#a23c40", "#8ac7d7", "#f5d787", "#44794d"),
]


def esc(value: str) -> str:
    return html.escape(value, quote=True)


def scallop_path() -> str:
    """A postage-edge silhouette with small, regular perforation scallops."""
    x0, y0, x1, y1, step, depth = 6.0, 6.0, 234.0, 294.0, 7.0, 3.3
    pts = []
    # Offset each edge in and out with a soft, dense paper-perforation rhythm.
    for xa, ya, xb, yb, nx, ny in [
        (x0, y0, x1, y0, 0, -1), (x1, y0, x1, y1, 1, 0),
        (x1, y1, x0, y1, 0, 1), (x0, y1, x0, y0, -1, 0)]:
        length = math.hypot(xb-xa, yb-ya)
        count = max(2, round(length / step))
        for i in range(count):
            t = i / count
            wave = depth * math.cos(2 * math.pi * (t * length / step))
            pts.append((xa + (xb-xa)*t + nx*wave, ya + (yb-ya)*t + ny*wave))
    return 'M' + ' '.join((f'{x:.1f},{y:.1f}' if i == 0 else f'L{x:.1f},{y:.1f}') for i,(x,y) in enumerate(pts)) + 'Z'


def pine(x: float, base: float, scale: float = 1.0, color: str = "#285b42") -> str:
    return f'''<g transform="translate({x:.1f} {base:.1f}) scale({scale:.2f})">
      <path d="M-3 -6h6v11h-6z" fill="#8e603e"/>
      <path d="M0 -82 -18 -54 -8 -55 -26 -34 -12 -35 -31 -11H31L12 -35h14L8 -55h10z" fill="{color}" stroke="#214a39" stroke-width="1.5" stroke-linejoin="round"/>
      <path d="M-15 -56q8 4 15 3 8 0 15-4M-21 -36q10 4 21 4 11 0 21-5M-27 -14q13 4 27 4t27-4" fill="none" stroke="#fff5dc" stroke-width="4" stroke-linecap="round" opacity=".92"/>
      <circle cx="-9" cy="-43" r="2.6" fill="#f3c766"/><circle cx="9" cy="-24" r="2.4" fill="#c54842"/>
    </g>'''


def window(x: float, y: float, w: float = 8, h: float = 13, color: str = "#ffd678") -> str:
    return f'<path d="M{x-w/2:.1f} {y+h/2:.1f}v{-h/2+2:.1f}q0-4 {w/2:.1f}-4t{w/2:.1f} 4v{h/2-2:.1f}z" fill="{color}" stroke="#fff2c9" stroke-width="1.2"/>'


def dome(cx: float, base: float, rx: float = 12, color: str = "#4a9b82", stripe: str = "#f1ca70") -> str:
    return f'''<g>
      <rect x="{cx-rx*.58:.1f}" y="{base-7:.1f}" width="{rx*1.16:.1f}" height="8" rx="2" fill="{stripe}"/>
      <path d="M{cx-rx:.1f} {base-6:.1f}Q{cx:.1f} {base-rx*2.25:.1f} {cx+rx:.1f} {base-6:.1f}Z" fill="{color}" stroke="#fff1d1" stroke-width="1.5"/>
      <path d="M{cx:.1f} {base-rx*2.15:.1f}v-8" stroke="#dbb45d" stroke-width="1.5"/><circle cx="{cx:.1f}" cy="{base-rx*2.55:.1f}" r="2.2" fill="#ffe38b"/>
      <path d="M{cx-rx*.58:.1f} {base-14:.1f}q{rx*.58:.1f} 5 {rx*1.16:.1f} 0" fill="none" stroke="{stripe}" stroke-width="2" opacity=".9"/>
    </g>'''


def church(cx: float = 120, base: float = 202, w: float = 78, h: float = 64,
           body: str = "#f8e9c7", roof: str = "#c24943", dome_color: str = "#468c79",
           dome_count: int = 1) -> str:
    x = cx - w/2
    top = base - h
    art = [f'<rect x="{x:.1f}" y="{top+18:.1f}" width="{w:.1f}" height="{h-18:.1f}" rx="3" fill="{body}" stroke="#fff6de" stroke-width="2"/>',
           f'<path d="M{x-5:.1f} {top+20:.1f}L{cx:.1f} {top:.1f}l{w/2+5:.1f} 20z" fill="{roof}" stroke="#fff2d5" stroke-width="2"/>']
    for frac in (.24, .5, .76):
        art.append(window(x+w*frac, top+39, 8, 16))
    art.append(f'<rect x="{cx-5:.1f}" y="{base-25:.1f}" width="10" height="25" rx="5" fill="#7d4537"/>')
    if dome_count == 1:
        art.append(dome(cx, top+7, min(16, w*.19), dome_color))
    else:
        xs = [cx-(dome_count-1)*w*.13 + i*w*.26 for i in range(dome_count)]
        for i, dx in enumerate(xs):
            art.append(dome(dx, top+12, min(10, w*.12), [dome_color, "#d64e46", "#e7b94d", "#5596ad", "#9a6a9d"][i % 5]))
    return ''.join(art)


def bridge(cx: float = 120, y: float = 169, w: float = 155, color: str = "#b94c43", water: str = "#4d9cbb", arches: int = 3) -> str:
    x = cx-w/2
    art = [f'<path d="M15 {y+27:.1f}q45-15 90 0t105 0v45H15z" fill="{water}" opacity=".93"/>',
           f'<path d="M{x:.1f} {y:.1f}q{w/2:.1f} 16 {w:.1f} 0" fill="none" stroke="#f8e8bf" stroke-width="7"/>',
           f'<path d="M{x:.1f} {y-6:.1f}q{w/2:.1f} 16 {w:.1f} 0" fill="none" stroke="{color}" stroke-width="4"/>']
    for i in range(arches):
        bx = x+10+i*(w-20)/max(1, arches-1)
        art.append(f'<path d="M{bx-10:.1f} {y+7:.1f}q10 20 20 0" fill="none" stroke="{color}" stroke-width="3"/>')
        art.append(f'<circle cx="{bx:.1f}" cy="{y-7:.1f}" r="2.5" fill="#ffe181"/>')
    for bx in (x+8, x+w-8):
        art.append(f'<path d="M{bx:.1f} {y-19:.1f}v26" stroke="{color}" stroke-width="4"/><path d="M{bx-4:.1f} {y-19:.1f}h8" stroke="#fff1cc" stroke-width="3"/>')
    return ''.join(art)


def tower(x: float, base: float = 201, w: float = 34, h: float = 78,
          body: str = "#bd5144", roof: str = "#3e7651", style: str = "spire") -> str:
    top = base-h
    art = [f'<rect x="{x-w/2:.1f}" y="{top+17:.1f}" width="{w:.1f}" height="{h-17:.1f}" rx="3" fill="{body}" stroke="#fff0d0" stroke-width="2"/>',
           f'<path d="M{x-w/2-5:.1f} {top+18:.1f}l{w/2+5:.1f} {-18:.1f} {w/2+5:.1f} 18z" fill="{roof}" stroke="#fff0d0" stroke-width="2"/>',
           window(x, top+39, 9, 17)]
    if style == "spire":
        art.append(f'<path d="M{x-5:.1f} {top+17:.1f}L{x:.1f} {top-17:.1f}l5 34z" fill="{roof}" stroke="#fff0d0" stroke-width="1.5"/>')
        art.append(f'<circle cx="{x:.1f}" cy="{top-18:.1f}" r="2.2" fill="#ffdc72"/>')
    else:
        art.append(dome(x, top+18, w*.38, roof, "#f3cb70"))
    return ''.join(art)


def motif(kind: str, a: str, b: str, gold: str, green: str, n: int) -> str:
    # A distinct landmark vignette for each stop; all shapes are original SVG art.
    if kind == "moscow_kremlin":
        return f'''<path d="M40 189V144h160v45z" fill="#b6453d" stroke="#ffe7b9" stroke-width="2"/><path d="M36 145h168v8H36z" fill="#e5bf70"/>
        {tower(64,188,31,83,"#bd493c","#3b8759")} {tower(120,188,36,104,"#c13f3d","#38916a")} {tower(176,188,31,83,"#bd493c","#3b8759")}
        {church(120,187,55,51,"#fff2d1","#c94743","#38a17b",5)}'''
    if kind in ("sergiev_cathedral", "ryazan_cathedral", "petrozavodsk_lake_church", "suzdal_domes"):
        colors = {"sergiev_cathedral": ("#f9edcf", "#4a87b5", 1), "ryazan_cathedral": ("#f5e7c6", "#4e83bd", 3), "petrozavodsk_lake_church": ("#f8e5bd", "#c84943", 1), "suzdal_domes": ("#f3e5c9", "#5486a4", 3)}[kind]
        water = '<path d="M15 185q42-10 83 0t127 0v38H15z" fill="#62b5d0" opacity=".9"/>' if kind == "petrozavodsk_lake_church" else ''
        return water + church(120, 199, 88, 72, colors[0], "#b94d42", colors[1], colors[2]) + church(74, 199, 36, 43, "#fff1d5", "#bd4d43", "#e2b951", 1)
    if kind in ("yaroslavl_bear", "perm_bear_bridge"):
        bear = '''<g transform="translate(169 157) scale(.55)"><circle cx="-14" cy="-31" r="12" fill="#925b3d"/><circle cx="14" cy="-31" r="12" fill="#925b3d"/><ellipse cx="0" cy="8" rx="28" ry="36" fill="#a96e46"/><ellipse cx="0" cy="-26" rx="23" ry="22" fill="#aa7047"/><ellipse cx="0" cy="-17" rx="12" ry="8" fill="#f8dfb8"/><circle cx="-8" cy="-28" r="2"/><circle cx="8" cy="-28" r="2"/><path d="M-5-13q5 6 10 0" fill="none" stroke="#624030" stroke-width="2"/><path d="M-12 36v14m24-14v14" stroke="#72472f" stroke-width="7" stroke-linecap="round"/></g>'''
        house = church(98, 199, 80, 62, "#fff0d1", "#ba4b42", "#488a72", 3)
        water = bridge(120, 175, 180, "#b84640", "#59a9c3", 3) if kind == "perm_bear_bridge" else '<path d="M18 191q46-16 96-2t108 0v33H18z" fill="#4f9dba"/>'
        return water + house + bear
    if kind == "kostroma_terem":
        return f'''<path d="M64 199V132h112v67z" fill="#ecdcbd" stroke="#fff7e0" stroke-width="2"/><path d="M54 138 120 97l66 41z" fill="#477d91" stroke="#fff4d6" stroke-width="3"/>
        {tower(83,197,27,78,"#8cc9db","#f6d578")} {tower(157,197,27,78,"#8cc9db","#f6d578")}<rect x="105" y="160" width="30" height="39" rx="15" fill="#b44b43" stroke="#fff3d3" stroke-width="2"/>{window(120,145,12,20,"#ffdf7d")}'''
    if kind == "vologda_lace":
        return f'''<rect x="59" y="145" width="122" height="55" rx="4" fill="#996644" stroke="#fff0d1" stroke-width="3"/><path d="M51 146 120 106l69 40z" fill="#8a493f" stroke="#fff0d1" stroke-width="3"/><path d="M62 158h116M62 173h116M62 188h116M79 146v53m21-53v53m21-53v53m21-53v53m21-53v53" stroke="#f8edce" stroke-width="3"/>
        <path d="M120 84l6 14 14 1-10 9 3 14-13-7-13 7 3-14-10-9 14-1z" fill="none" stroke="{gold}" stroke-width="3"/>'''
    if kind in ("arkhangelsk_harbor", "magadan_lighthouse", "kaliningrad_amber_lighthouse"):
        lighthouse_color = "#f1eee1" if kind != "kaliningrad_amber_lighthouse" else "#f4d178"
        ship = '<path d="M50 186h78l-12 13H65z" fill="#b64a42" stroke="#fff1d3" stroke-width="2"/><path d="M88 147v39m0-33 24 23H88z" fill="#fff5df" stroke="#577887" stroke-width="2"/>' if kind == "arkhangelsk_harbor" else ''
        amber = '<path d="M169 113 185 130 169 151 153 130z" fill="#f1a941" stroke="#fff0b9" stroke-width="3"/>' if kind == "kaliningrad_amber_lighthouse" else ''
        return f'''<path d="M15 180q50-16 100 0t110 0v46H15z" fill="#459dbb"/><path d="M15 196q46-12 93 0t117 0" fill="none" stroke="#d5f1ef" stroke-width="3"/>
        <path d="M149 195V118l13-20 13 20v77z" fill="{lighthouse_color}" stroke="#fff3d4" stroke-width="3"/><rect x="153" y="119" width="18" height="20" fill="#c54b40"/><path d="M145 119h34l-5-10h-24z" fill="#a83c3d"/><path d="M161 95V82" stroke="#f7d46d" stroke-width="3"/><path d="M157 85h9" stroke="#fff0b8" stroke-width="2"/>{ship}{amber}'''
    if kind == "murmansk_aurora":
        return f'''<path d="M17 132Q52 54 94 122T174 105T224 91" fill="none" stroke="#55d3a7" stroke-width="12" opacity=".72"/><path d="M18 146Q56 81 98 138t90-15 36-17" fill="none" stroke="#78cde5" stroke-width="6" opacity=".85"/><path d="M18 188 57 145l26 28 35-52 38 50 35-31 34 37v34H18z" fill="#335978" stroke="#d9eff3" stroke-width="3"/><path d="M70 161l13 12 35-52 13 18" fill="none" stroke="#fff" stroke-width="5"/>
        <circle cx="190" cy="83" r="13" fill="#fff0c8"/>'''
    if kind == "vyborg_castle":
        return f'''<path d="M55 200V140h38V99h54v30h39v71z" fill="#897e69" stroke="#fff1d2" stroke-width="3"/><path d="M49 141h50v-8h-50zm38-39h58v-8H87zm52 39h53v-8h-53z" fill="#b9ad91"/><path d="M87 101 114 77l27 24z" fill="#a9473f" stroke="#fff3d4" stroke-width="2"/><path d="M110 199v-29q12-20 24 0v29" fill="#415b68" stroke="#f4e6c4" stroke-width="2"/><path d="M112 127h12v17h-12z" fill="#ffd66e"/>'''
    if kind in ("petersburg_bridge_spire", "tver_bridge", "nizhny_confluence", "tver_bridge", "rostov_don_bridge"):
        water = '<path d="M15 178q50-13 100 0t110 0v51H15z" fill="#4b9fbf"/><path d="M18 207q44-9 88 0t110 0" fill="none" stroke="#d9f3e9" stroke-width="3"/>'
        bridge_art = bridge(120, 166, 180, "#c44c41" if kind != "petersburg_bridge_spire" else "#4e6f82", "#4b9fbf", 4)
        spire = '<path d="M120 163V102l-12 7 12-43 12 43-12-7" fill="#d8aa54" stroke="#fff0c3" stroke-width="2"/><circle cx="120" cy="63" r="4" fill="#ffe48e"/>' if kind == "petersburg_bridge_spire" else ''
        hills = '<path d="M19 173 66 135l31 20 34-48 47 54 26-23v38z" fill="#537d75" stroke="#fff0d3" stroke-width="2"/>' if kind == "nizhny_confluence" else ''
        return water + hills + bridge_art + spire
    if kind == "novgorod_bell":
        return f'''{church(115,199,82,66,"#f4e5c8","#a8413b","#397c53",1)}<path d="M171 113q17-18 34 0v38h-34z" fill="#d9b65d" stroke="#fff1c4" stroke-width="2"/><path d="M167 151h42m-32 1q11 12 22 0" fill="none" stroke="#9d6939" stroke-width="3"/><path d="M188 126v15" stroke="#8a5934" stroke-width="3"/>'''
    if kind in ("pskov_wall", "smolensk_fortress", "tobolsk_white_kremlin"):
        body = "#f0e4c7" if kind == "tobolsk_white_kremlin" else ("#b94d3f" if kind == "smolensk_fortress" else "#b8a98a")
        roof = "#4387a1" if kind == "tobolsk_white_kremlin" else "#396f4d"
        return f'''<path d="M36 199V151h168v48z" fill="{body}" stroke="#fff5dc" stroke-width="3"/><path d="M34 151h172v-8H34z" fill="{roof}"/><path d="M45 143v-14h12v14m19 0v-14h12v14m20 0v-14h12v14m20 0v-14h12v14m20 0v-14h12v14m16 0v-14h12v14" fill="{body}" stroke="#fff2d4" stroke-width="2"/>
        {tower(75,198,26,77,body,roof,'dome' if kind=='tobolsk_white_kremlin' else 'spire')} {tower(165,198,26,77,body,roof,'dome' if kind=='tobolsk_white_kremlin' else 'spire')}'''
    if kind == "tula_gingerbread":
        return f'''<path d="M63 199v-63l57-40 57 40v63z" fill="#b87542" stroke="#fff5dd" stroke-width="3"/><path d="M54 138 120 87l66 51" fill="none" stroke="#fff6dd" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="M70 144h100v10H70zm20-17v61m60-61v61" stroke="#ffe0a0" stroke-width="4"/><rect x="108" y="164" width="24" height="35" rx="11" fill="#734631"/><circle cx="87" cy="165" r="6" fill="#cf4c43"/><circle cx="153" cy="165" r="6" fill="#4c8a5d"/><path d="M120 78l4 9 10 1-7 7 2 10-9-5-9 5 2-10-7-7 10-1z" fill="#ffd86d"/>'''
    if kind == "kazan_mosque":
        return f'''<rect x="67" y="147" width="106" height="54" rx="4" fill="#f3ead8" stroke="#fff5dd" stroke-width="3"/><path d="M63 150q57-40 114 0" fill="#45a8af" stroke="#fff0cb" stroke-width="3"/><path d="M69 146v-45h12v45m78 0v-45h12v45" fill="#f3ead8" stroke="#fff4d4" stroke-width="2"/><path d="M69 101l6-15 6 15m78 0 6-15 6 15" fill="#d7b25e"/><path d="M120 138v-49" stroke="#fff1d1" stroke-width="2"/><path d="M115 92q5-14 10 0" fill="#43aab2" stroke="#fff2d1" stroke-width="2"/><path d="M92 179v-17q8-12 16 0v17m21 0v-17q8-12 16 0v17" fill="#fff5dc" stroke="#d5bd8c" stroke-width="2"/>'''
    if kind in ("samara_rocket", "yekaterinburg_arch"):
        if kind == "samara_rocket":
            return f'''<path d="M15 184q50-17 100 0t110 0v42H15z" fill="#459fbd"/><path d="M120 83q-22 25-22 66v30h44v-30q0-41-22-66z" fill="#e7e9df" stroke="#587d8a" stroke-width="3"/><path d="M120 83l-10 16h20z" fill="#c64b41"/><circle cx="120" cy="121" r="9" fill="#71c4df" stroke="#fff" stroke-width="3"/><path d="M99 158 83 176h16m43-18 16 18h-16" fill="#bd4b40"/><path d="M112 179q8 17 16 0" fill="#f3b74c"/>'''
        return f'''<path d="M18 195 60 150l40 29 35-57 38 52 30-28v54z" fill="#537c64" stroke="#fff2d2" stroke-width="3"/><path d="M68 188V126q0-35 52-35t52 35v62" fill="none" stroke="#d3ae5e" stroke-width="9"/><path d="M68 125q52-34 104 0" fill="none" stroke="#fff4d3" stroke-width="4"/><rect x="104" y="139" width="32" height="47" rx="12" fill="#4793ab" stroke="#fff4d3" stroke-width="3"/><path d="M120 137v45m-14-23h28" stroke="#fff0c6" stroke-width="3"/>'''
    if kind in ("ufa_honey_hills", "tyumen_hot_springs"):
        if kind == "ufa_honey_hills":
            return f'''<path d="M15 190q40-48 82 0t108-8v44H15z" fill="#4a8c69"/><path d="M15 202q48-20 94 0t96-3v28H15z" fill="#76b7c0"/><path d="M168 124l13 8v15l-13 8-13-8v-15zM188 144l9 6v11l-9 6-9-6v-11z" fill="#eebc4d" stroke="#fff0c8" stroke-width="2"/><path d="M168 124v31m-13-16h26" stroke="#fff2c9" stroke-width="2"/>'''
        return f'''<path d="M46 198v-55h148v55z" fill="#9b6743" stroke="#fff0d1" stroke-width="3"/><path d="M39 144 120 99l81 45" fill="#b4433d" stroke="#fff0d1" stroke-width="3"/><path d="M64 158h112" stroke="#f2d99f" stroke-width="4"/><path d="M72 177q-12-14 0-26t0-25m32 50q-12-14 0-26t0-25m32 50q-12-14 0-26t0-25" fill="none" stroke="#fff9e8" stroke-width="5" stroke-linecap="round"/><path d="M45 203q30-15 60 0t60 0" fill="none" stroke="#69b9ca" stroke-width="6"/>'''
    if kind == "yakutsk_ice_city":
        return f'''<path d="M55 196V144l23-24 23 24v52m13 0V119l26-37 26 37v77m9 0v-50l20-21 20 21v50" fill="#92dce7" stroke="#fff" stroke-width="3"/><path d="M120 82l7-12 8 12-8 11z" fill="#fff4c6" stroke="#fff" stroke-width="2"/><path d="M80 157h38m-38 16h38m21-29h33m-33 16h33m-33 16h33" stroke="#d7faff" stroke-width="3"/><path d="M43 201q77-15 154 0" fill="none" stroke="#fff" stroke-width="5"/>'''
    if kind == "novosibirsk_opera":
        return f'''<path d="M49 197v-46h24v-20h94v20h24v46z" fill="#f1e5ca" stroke="#fff3d6" stroke-width="3"/><path d="M72 151q48-60 96 0" fill="#c6b58e" stroke="#fff2d2" stroke-width="3"/><path d="M92 150q28-36 56 0" fill="#a7d5d9" stroke="#fff4d7" stroke-width="3"/><path d="M67 166v29m20-29v29m20-29v29m26-29v29m20-29v29m20-29v29" stroke="#b94740" stroke-width="4"/><path d="M44 198h152" stroke="#d3ad5a" stroke-width="4"/>'''
    if kind == "krasnoyarsk_stolby":
        return f'''<path d="M24 200 45 132l19-17 16 17 9 68m5 0 10-84 18-34 19 34 10 84m5 0 8-65 19-25 21 25 8 65" fill="#687f7f" stroke="#fff2d6" stroke-width="3" stroke-linejoin="round"/><path d="M45 132l19-17 16 17m28-16 18-34 19 34m27 19 19-25 21 25" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round"/><path d="M15 203q55-9 105 0t105 0v25H15z" fill="#4aa0b9"/>'''
    if kind == "irkutsk_baikal_house":
        return f'''<path d="M48 198v-61h144v61z" fill="#a66b43" stroke="#fff0ce" stroke-width="3"/><path d="M39 140 120 95l81 45" fill="#4c7190" stroke="#fff0d4" stroke-width="4"/><path d="M54 150h132m-132 14h132m-132 14h132" stroke="#e7c58a" stroke-width="3"/><rect x="109" y="163" width="23" height="35" fill="#623d31"/><path d="M15 209q52-15 105 0t105 0v19H15z" fill="#52b6d0"/><path d="m56 212 12-5 12 5m42-4 12 5 12-5m24 5 12-5 12 5" fill="none" stroke="#e1f8ff" stroke-width="3"/>'''
    if kind == "ulanude_datsan":
        return f'''<path d="M66 198v-40h108v40z" fill="#d94c42" stroke="#fff2d3" stroke-width="3"/><path d="M56 160q64-37 128 0" fill="#d8ab53" stroke="#fff0cf" stroke-width="3"/><path d="M72 146q48-29 96 0" fill="#438c86" stroke="#fff2d3" stroke-width="3"/><path d="M89 132q31-26 62 0" fill="#e2b65e" stroke="#fff2d3" stroke-width="3"/><path d="M108 116q12-21 24 0" fill="#bd4a40" stroke="#fff1cc" stroke-width="3"/><path d="M86 178h68m-50-17v37m32-37v37" stroke="#ffe08b" stroke-width="4"/>'''
    if kind == "kamchatka_volcanoes":
        return f'''<path d="M15 199 53 129l27 30 39-88 44 89 23-31 39 70z" fill="#547d86" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M101 123 119 71l19 53-18-12zM42 149l11-20 13 17m106 1 13-23 15 26" fill="#fff" stroke="#d6eff2" stroke-width="3"/><path d="M15 201q55-12 105 0t105 0v27H15z" fill="#499bb7"/><path d="M18 213q45-10 88 0t104 0" fill="none" stroke="#dbf3e9" stroke-width="3"/>'''
    if kind == "sakhalin_cable_mountain":
        return f'''<path d="M18 200 58 127l26 30 42-70 46 71 23-24 31 66z" fill="#587a75" stroke="#fff1d4" stroke-width="3"/><path d="M43 154l15-27 26 30m27-45 22-25 22 43" fill="none" stroke="#fff" stroke-width="6"/><path d="M59 121v54m118-47v49M59 126h118" fill="none" stroke="#755d48" stroke-width="3"/><path d="M109 128h22v17h-22z" fill="#c64b43" stroke="#fff4d6" stroke-width="2"/><path d="M109 128l11-9 11 9" fill="#e3bd68"/>'''
    if kind in ("khabarovsk_amur_bridge", "vladivostok_golden_bridge", "omsk_ice_bridge"):
        water = "#58a9c5" if kind != "omsk_ice_bridge" else "#a7dce7"
        color = "#c74c41" if kind == "khabarovsk_amur_bridge" else ("#e2b957" if kind == "vladivostok_golden_bridge" else "#527b90")
        art = bridge(120, 165, 180, color, water, 5)
        if kind == "vladivostok_golden_bridge":
            art += '<path d="M54 145 120 101l66 44M54 145l18 19m114-19-18 19" fill="none" stroke="#e4be68" stroke-width="2"/>'
        if kind == "khabarovsk_amur_bridge":
            art += '<path d="M39 149v18m23-18v14m23-14v11m23-11v10m23-10v10m23-10v11m23-11v14m23-14v18" stroke="#fff0ca" stroke-width="2"/>'
        return art
    if kind == "sochi_sea_mountain":
        return f'''<path d="M15 174 65 110l35 33 38-69 52 81 25-29v84H15z" fill="#73938a" stroke="#fff" stroke-width="3"/><path d="M122 100 138 74l17 37-16-10z" fill="#fff"/><path d="M15 183q54-14 105 0t105 0v45H15z" fill="#51aec6"/><path d="M183 196v-48m0 6q-20-16-22-4 12 11 22 9m0 4q17-16 21-5-8 12-21 11" fill="none" stroke="#397b54" stroke-width="4" stroke-linecap="round"/><path d="M15 199q46-10 89 0" fill="none" stroke="#e3f7e9" stroke-width="4"/>'''
    if kind == "volgograd_star":
        return f'''<path d="M120 73 135 121l51-18-31 45 46 29-54 2-5 51-22-45-41 29 20-49-48-24 53-8z" fill="#bd493e" stroke="#ffe5af" stroke-width="3"/><path d="M120 105v94" stroke="#fff2d0" stroke-width="5"/><path d="M97 188q23-16 46 0v12H97z" fill="#e3bd65"/><circle cx="120" cy="108" r="8" fill="#ffd978"/>'''
    if kind == "tyumen_hot_springs":
        # Related local architecture plus rising warm water, composed separately from the Ufa motif.
        return f'''<path d="M48 198v-58h144v58z" fill="#a56b45" stroke="#fff0d0" stroke-width="3"/><path d="M41 141 120 99l79 42" fill="#4d7658" stroke="#fff0d0" stroke-width="3"/><path d="M65 154h110m-110 14h110m-110 14h110" stroke="#e7c784" stroke-width="3"/><path d="M73 132q-14-15 0-29t0-25m45 54q-14-15 0-29t0-25m45 54q-14-15 0-29t0-25" fill="none" stroke="#fff8e8" stroke-width="5" stroke-linecap="round"/><path d="M44 204q38-13 76 0t76 0" fill="none" stroke="#58b9ca" stroke-width="6"/>'''
    if kind == "novosibirsk_opera":
        return ""
    if kind == "ustyug_fairytale_house":
        return f'''<path d="M46 199v-62l74-48 74 48v62z" fill="#e1bc68" stroke="#fff2d4" stroke-width="3"/><path d="M38 141 120 79l82 62" fill="none" stroke="#bd493f" stroke-width="10" stroke-linejoin="round"/><path d="M72 158h96m-83-14v48m70-48v48" stroke="#fff2d4" stroke-width="5"/><rect x="107" y="160" width="26" height="39" rx="13" fill="#47774e" stroke="#fff1d0" stroke-width="2"/><path d="M120 73l5 10 11 1-8 7 2 11-10-5-10 5 2-11-8-7 11-1z" fill="#fff0a7" stroke="#d4a843" stroke-width="2"/>
        <circle cx="76" cy="145" r="5" fill="#c94843"/><circle cx="164" cy="145" r="5" fill="#458f6a"/>'''
    if kind == "arkhangelsk_harbor":
        return ""
    if kind == "vyborg_castle":
        return ""
    if kind == "tver_bridge":
        return ""
    if kind == "rostov_don_bridge":
        return ""
    if kind == "nizhny_confluence":
        return ""
    if kind == "petersburg_bridge_spire":
        return ""
    # Every route item must have a hand-assigned motif; do not silently fall back to a generic picture.
    raise ValueError(f"No SVG motif implemented for {kind} (stop {n})")


def generate_stamp(day: int, city: str, fact: str) -> str:
    header, sky, gold, green = PALETTES[(day - 1) % len(PALETTES)]
    kind = MOTIFS[day]
    # Use a lighter version of the assigned sky color as a playful snowy-evening backdrop.
    scene = [f'<rect x="15" y="49" width="210" height="183" fill="{sky}"/>']
    scene.append('<circle cx="181" cy="80" r="15" fill="#fff1bc" opacity=".92"/>')
    scene.append('<circle cx="176" cy="75" r="13" fill="#d4eaf1" opacity=".7"/>')
    for i, (sx, sy, sr) in enumerate([(47, 91, 2.2), (89, 71, 1.7), (145, 93, 1.8), (207, 109, 2), (69, 116, 1.5), (158, 62, 1.4)]):
        scene.append(f'<path d="M{sx} {sy-sr*2:.1f}v{sr*4:.1f}M{sx-sr*2:.1f} {sy}h{sr*4:.1f}" stroke="#fff6db" stroke-width="1.4" stroke-linecap="round" opacity=".9"/>')
    scene.append(f'<path d="M15 175 53 141l20 19 34-48 32 43 27-30 59 52v37H15z" fill="{green}" opacity=".58"/>')
    scene.append('<path d="M15 187q38-13 76 0t75 0 59 0v45H15z" fill="#eff5e7"/>')
    scene.append(pine(30, 202, .48, "#285b42"))
    scene.append(pine(211, 204, .46, "#356a48"))

    # Add a small local light-window skyline behind the main landmark.
    for bx, bh, bw in [(51, 26, 17), (185, 31, 19)]:
        scene.append(f'<rect x="{bx}" y="{176-bh}" width="{bw}" height="{bh}" rx="2" fill="#d8e4d8" opacity=".85"/>')
        scene.append(window(bx+bw/2, 164, 5, 8, "#ffd978"))

    scene.append(f'<g filter="url(#artshadow{day})">{motif(kind, header, sky, gold, green, day)}</g>')
    scene.append('<path d="M15 207q48-17 97 0t113-1v26H15z" fill="#fffaf0" opacity=".96"/>')
    scene.append('<path d="M15 216q50-12 102 0t108 0" fill="none" stroke="#c8dbe0" stroke-width="2"/>')
    # Tiny sparkles across the snow foreground.
    for sx, sy in [(45, 216), (74, 225), (168, 215), (194, 225)]:
        scene.append(f'<circle cx="{sx}" cy="{sy}" r="1.7" fill="#e6bd57"/>')

    month = "ДЕК" if day <= 31 else "ЯНВ"
    city_size = 20 if len(city) <= 12 else (18 if len(city) <= 17 else 16)
    fact_size = 12 if len(fact) <= 24 else 10.5
    # Long compound city names get two centered lines rather than being squeezed or clipped.
    if len(city) > 17:
        if " " in city:
            words = city.split()
            split_at = max(1, min(len(words) - 1, len(words) // 2))
            city_parts = [" ".join(words[:split_at]), " ".join(words[split_at:])]
        elif "-" in city:
            split_at = city.find("-") + 1
            city_parts = [city[:split_at], city[split_at:]]
        else:
            city_parts = [city[:len(city)//2], city[len(city)//2:]]
        city_markup = (f'<text x="120" y="246" text-anchor="middle" textLength="194" lengthAdjust="spacingAndGlyphs" font-family="Georgia,serif" font-size="{city_size}" font-weight="700" fill="#174638">'
                       f'<tspan x="120">{esc(city_parts[0])}</tspan><tspan x="120" dy="15">{esc(city_parts[1])}</tspan></text>')
        fact_y = 278
    else:
        city_markup = (f'<text x="120" y="255" text-anchor="middle" textLength="198" lengthAdjust="spacingAndGlyphs" font-family="Georgia,serif" font-size="{city_size}" font-weight="700" fill="#174638">{esc(city)}</text>')
        fact_y = 277
    markup = f'''<svg xmlns="http://www.w3.org/2000/svg" width="240" height="300" viewBox="0 0 240 300" role="img" aria-labelledby="title{day} desc{day}">
  <title id="title{day}">Почтовая марка «{esc(city)}»</title>
  <desc id="desc{day}">Иллюстрированная зимняя марка остановки {day}: {esc(city)}. {esc(fact)}.</desc>
  <defs>
    <linearGradient id="sky{day}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{sky}"/><stop offset="1" stop-color="#d9edf0"/></linearGradient>
    <linearGradient id="paper{day}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fffaf0"/><stop offset="1" stop-color="#f0dfbd"/></linearGradient>
    <clipPath id="scene{day}"><rect x="15" y="49" width="210" height="183" rx="10"/></clipPath>
    <filter id="shadow{day}" x="-20%" y="-15%" width="140%" height="140%"><feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="#223a32" flood-opacity=".18"/></filter>
    <filter id="artshadow{day}" x="-15%" y="-15%" width="130%" height="140%"><feDropShadow dx="0" dy="2" stdDeviation="1.5" flood-color="#263d38" flood-opacity=".22"/></filter>
  </defs>
  <g filter="url(#shadow{day})">
    <path d="{scallop_path()}" fill="#fffaf0" stroke="{header}" stroke-width="2.5" stroke-linejoin="round"/>
    <path d="{scallop_path()}" transform="translate(5 5) scale(.955 .966)" fill="none" stroke="#fffdf5" stroke-width="2.5" stroke-dasharray="0.1 7" stroke-linecap="round"/>
    <rect x="14" y="13" width="212" height="30" rx="8" fill="{green}"/>
    <path d="M25 28l3-6 3 6 6 .8-4.4 4.2 1 6-5.6-3-5.6 3 1-6-4.4-4.2z" fill="{gold}" transform="translate(0 -2) scale(.65) translate(12 13)"/>
    <text x="120" y="32" text-anchor="middle" font-family="Georgia,serif" font-size="8.8" font-weight="700" letter-spacing=".65" fill="#fff8e7">НОВОГОДНИЙ ЭКСПРЕСС</text>
    <g clip-path="url(#scene{day})"><rect x="15" y="49" width="210" height="183" fill="{sky}"/><g transform="translate(16 5) scale(.86)">{''.join(scene[1:])}</g></g>
    <rect x="15" y="49" width="210" height="183" rx="10" fill="none" stroke="#fffaf0" stroke-width="2"/>
    <g>
      <circle cx="40" cy="70" r="20" fill="{header}" stroke="#fff7dd" stroke-width="2.4"/>
      <circle cx="40" cy="70" r="16" fill="none" stroke="#ffda83" stroke-width="1" opacity=".9"/>
      <text x="40" y="69" text-anchor="middle" font-family="Georgia,serif" font-size="17" font-weight="700" fill="#fffaf0">{day:02d}</text>
      <text x="40" y="80" text-anchor="middle" font-family="Arial,sans-serif" font-size="7" font-weight="700" letter-spacing=".5" fill="#ffe9b2">{month}</text>
    </g>
    <g opacity=".92" transform="rotate(10 201 71)">
      <circle cx="201" cy="71" r="16" fill="none" stroke="{header}" stroke-width="1.5"/>
      <circle cx="201" cy="71" r="12" fill="none" stroke="{header}" stroke-width="1" stroke-dasharray="1 3"/>
      <path d="M183 70h36m-31-5h26m-26 10h26" stroke="{header}" stroke-width="1" opacity=".8"/>
    </g>
    <rect x="14" y="220" width="212" height="63" rx="8" fill="#fffaf0" stroke="#e2cf9e" stroke-width="1.2"/>
    <path d="M24 228h192" stroke="{header}" stroke-width="1.6" stroke-dasharray="2 3" opacity=".6"/>
    {city_markup}
    <text x="120" y="{fact_y}" text-anchor="middle" textLength="194" lengthAdjust="spacingAndGlyphs" font-family="Arial,sans-serif" font-size="{fact_size}" font-weight="700" letter-spacing=".15" fill="{header}">{esc(fact)}</text>
  </g>
</svg>'''
    return markup


def main() -> None:
    STAMP_DIR.mkdir(parents=True, exist_ok=True)
    route_text = ROUTE_FILE.read_text(encoding="utf-8")
    pattern = re.compile(r"\{\s*day:\s*(\d+),\s*city:\s*'([^']+)',\s*fact:\s*'([^']+)'\s*(?:,\s*image:\s*'[^']*')?\s*\}")
    rows = [(int(m.group(1)), m.group(2), m.group(3)) for m in pattern.finditer(route_text)]
    if len(rows) != 41:
        raise SystemExit(f"Expected 41 route stops, found {len(rows)}")
    for day, city, fact in rows:
        if day not in MOTIFS:
            raise SystemExit(f"Missing motif for stop {day} ({city})")
        path = STAMP_DIR / f"stop-{day:02d}.svg"
        path.write_text(generate_stamp(day, city, fact), encoding="utf-8")
    route_text, count = pattern.subn(
        lambda m: "{ day: %s, city: '%s', fact: '%s', image: './stamps/stop-%02d.svg' }" %
                  (m.group(1), m.group(2), m.group(3), int(m.group(1))), route_text)
    if count != 41:
        raise SystemExit(f"Expected to add 41 stamp paths, updated {count}")
    ROUTE_FILE.write_text(route_text, encoding="utf-8")
    print(f"Generated {len(rows)} original illustrated city stamps in {STAMP_DIR}")


if __name__ == "__main__":
    main()
