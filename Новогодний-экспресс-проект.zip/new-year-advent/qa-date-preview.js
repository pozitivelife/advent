(() => {
  'use strict';
  const TZ = 'Europe/Moscow';
  const ACCESS_END = '2027-04-10';
  const TEST_MAX_DATE = '2027-04-11'; // First day after expiry, for QA only
  const DATE_KEY = 'advent-demo-date';
  const REG_KEY = 'advent-demo-registered-v2';
  const PAID_KEY = 'advent-demo-paid-v2';
  const $ = selector => document.querySelector(selector);
  const tasks = Array.isArray(window.ADVENT_TASKS) ? window.ADVENT_TASKS : [];

  function flag(key) {
    try { return sessionStorage.getItem(key) === '1'; } catch (_error) { return false; }
  }

  function actualToday() {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date());
    const values = Object.fromEntries(parts.filter(x => x.type !== 'literal').map(x => [x.type, x.value]));
    return `${values.year}-${values.month}-${values.day}`;
  }

  function today() {
    try { return sessionStorage.getItem(DATE_KEY) || actualToday(); }
    catch (_error) { return actualToday(); }
  }

  function dateFor(id) {
    return new Date(Date.UTC(2026, 11, id)).toISOString().slice(0, 10);
  }

  function format(iso) {
    const [year, month, day] = iso.split('-').map(Number);
    return new Intl.DateTimeFormat('ru-RU', {
      day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC'
    }).format(new Date(Date.UTC(year, month - 1, day)));
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, character => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[character]));
  }

  function render() {
    const selectedDate = today();
    const registered = flag(REG_KEY);
    const paid = flag(PAID_KEY);
    $('#testDate').value = selectedDate;
    $('#qaState').textContent = `Состояние теста: регистрация ${registered ? 'пройдена' : 'не пройдена'}, оплата ${paid ? 'симулирована' : 'не симулирована'}, дата ${format(selectedDate)}. Архив действует по ${format(ACCESS_END)} включительно.`;

    const rows = tasks.map(task => {
      const taskDate = dateFor(task.id);
      let status = 'Сначала регистрация';
      let className = 'locked';
      if (registered && !paid) status = 'Нужна оплата';
      else if (registered && paid && selectedDate > ACCESS_END) status = 'Срок доступа завершён';
      else if (registered && paid && taskDate > selectedDate) status = `Закрыто до ${format(taskDate)}`;
      else if (registered && paid) { status = 'Доступно'; className = 'open'; }
      const row = document.createElement('tr');
      row.innerHTML = `<td>${String(task.id).padStart(2, '0')}</td><td>${format(taskDate)}</td><td>${escapeHtml(task.title)}</td><td><span class="status ${className}">${escapeHtml(status)}</span></td>`;
      return row;
    });
    $('#taskTable').replaceChildren(...rows);
  }

  $('#setTestDate').addEventListener('click', () => {
    const value = $('#testDate').value;
    if (value < '2026-11-18' || value > TEST_MAX_DATE) return;
    try { sessionStorage.setItem(DATE_KEY, value); } catch (_error) {}
    render();
  });

  $('#resetTestDate').addEventListener('click', () => {
    try { sessionStorage.removeItem(DATE_KEY); } catch (_error) {}
    render();
  });

  render();
})();
