(() => {
  'use strict';

  const tasks = Array.isArray(window.ADVENT_TASKS) ? window.ADVENT_TASKS : [];
  const route = Array.isArray(window.ADVENT_ROUTE) ? window.ADVENT_ROUTE : [];
  const stopForTask = id => route.find(stop => stop.day === id) || { city: '', fact: '' };
  const EVENT_END = '2027-01-10';
  const ACCESS_END = '2027-04-10'; // 90 calendar days after the final task date
  const TZ = 'Europe/Moscow';
  const DONE_KEY = 'advent-demo-done-v1';
  const OPENED_KEY = 'advent-demo-opened-v1';
  const DEMO_REGISTERED_KEY = 'advent-demo-registered-v2';
  const DEMO_PAID_KEY = 'advent-demo-paid-v2';
  const DEMO_DATE_KEY = 'advent-demo-date';
  let lastFocused = null;
  let toastTimer = null;
  let authMode = 'register';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const sessionFlag = key => { try { return sessionStorage.getItem(key) === '1'; } catch (_error) { return false; } };
  const setSessionFlag = (key, value) => { try { sessionStorage.setItem(key, value ? '1' : '0'); } catch (_error) {} };

  function getDateInMoscow(date = new Date()) {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(date);
    const values = Object.fromEntries(parts.filter(part => part.type !== 'literal').map(part => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  }

  function getEffectiveDate() {
    try {
      const override = sessionStorage.getItem(DEMO_DATE_KEY);
      if (override && /^202[6-7]-\d{2}-\d{2}$/.test(override)) return override;
    } catch (_error) {}
    return getDateInMoscow();
  }

  function dateForTask(id) {
    return new Date(Date.UTC(2026, 11, id)).toISOString().slice(0, 10);
  }

  function formatLongDate(iso) {
    const [year, month, day] = iso.split('-').map(Number);
    return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' })
      .format(new Date(Date.UTC(year, month - 1, day)));
  }

  function formatShortDate(iso) {
    const [year, month, day] = iso.split('-').map(Number);
    return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short', timeZone: 'UTC' })
      .format(new Date(Date.UTC(year, month - 1, day))).replace('.', '');
  }

  function russianDays(number) {
    const n = Math.abs(number) % 100;
    const last = n % 10;
    if (n > 10 && n < 20) return 'дней';
    if (last === 1) return 'день';
    if (last >= 2 && last <= 4) return 'дня';
    return 'дней';
  }

  function utcDayNumber(iso) {
    const [year, month, day] = iso.split('-').map(Number);
    return Math.floor(Date.UTC(year, month - 1, day) / 86400000);
  }

  function updateCountdown() {
    const today = getDateInMoscow();
    const jan1_2027 = '2027-01-01';
    const firstOfNextYear = `${Number(today.slice(0, 4)) + 1}-01-01`;
    let label;
    let value;
    let message;

    if (today < jan1_2027) {
      const count = utcDayNumber(jan1_2027) - utcDayNumber(today);
      label = 'До Нового года осталось';
      value = `${count} ${russianDays(count)}`;
      message = 'Экспресс отправляется 1 декабря — впереди 41 остановка и столько же тёплых заданий.';
    } else if (today <= EVENT_END) {
      label = 'С Новым годом!';
      value = 'Праздник уже здесь';
      message = 'С Новым годом! Экспресс продолжает путь — впереди ещё города и находки.';
    } else {
      const count = utcDayNumber(firstOfNextYear) - utcDayNumber(today);
      label = 'До следующего Нового года осталось';
      value = `${count} ${russianDays(count)}`;
      message = 'Новый год уже наступил. Спасибо, что помогли зверятам вернуть праздничные находки.';
    }

    if ($('#heroCountdownLabel')) $('#heroCountdownLabel').textContent = label;
    if ($('#heroCountdownValue')) $('#heroCountdownValue').textContent = value;
    if ($('#countdownTitle')) $('#countdownTitle').textContent = label;
    if ($('#countdownMessage')) $('#countdownMessage').textContent = message;
    if (today < jan1_2027) {
      const count = utcDayNumber(jan1_2027) - utcDayNumber(today);
      if ($('#modalCountdownValue')) $('#modalCountdownValue').textContent = String(count);
      if ($('#modalCountdownUnit')) $('#modalCountdownUnit').textContent = russianDays(count);
    } else {
      if ($('#modalCountdownValue')) $('#modalCountdownValue').textContent = '✦';
      if ($('#modalCountdownUnit')) $('#modalCountdownUnit').textContent = 'праздник';
    }
    if ($('#todayLabel')) $('#todayLabel').textContent = formatLongDate(getEffectiveDate());
  }

  function getDoneIds() {
    try {
      const parsed = JSON.parse(localStorage.getItem(DONE_KEY) || '[]');
      return Array.isArray(parsed)
        ? Array.from(new Set(parsed.map(Number).filter(id => Number.isInteger(id) && id >= 1 && id <= tasks.length)))
        : [];
    } catch (_error) { return []; }
  }

  function saveDoneIds(ids) {
    try { localStorage.setItem(DONE_KEY, JSON.stringify(ids)); } catch (_error) {}
  }

  function getOpenedIds() {
    try {
      const parsed = JSON.parse(localStorage.getItem(OPENED_KEY) || '[]');
      return Array.isArray(parsed) ? Array.from(new Set(parsed.map(Number).filter(id => Number.isInteger(id) && id >= 1 && id <= tasks.length))) : [];
    } catch (_error) { return []; }
  }

  function saveOpenedIds(ids) {
    try { localStorage.setItem(OPENED_KEY, JSON.stringify(Array.from(new Set(ids)))); } catch (_error) {}
  }

  function mascotForTask(task) {
    return typeof window.getAdventMascot === 'function'
      ? window.getAdventMascot(task.id)
      : { name: 'Снежок', species: 'зимний друг' };
  }

  function mascotMarkup(task) {
    return typeof window.renderAdventMascot === 'function'
      ? window.renderAdventMascot(task.id)
      : `<span class="mascot-fallback" aria-hidden="true">${escapeHtml(task.icon)}</span>`;
  }

  function russianToyWord(number) {
    const n = Math.abs(number) % 100;
    const last = n % 10;
    if (n > 10 && n < 20) return 'игрушек';
    if (last === 1) return 'игрушка';
    if (last >= 2 && last <= 4) return 'игрушки';
    return 'игрушек';
  }

  function treePoints() {
    const rows = [
      { count: 1, y: 72, step: 0 },
      { count: 3, y: 108, step: 35 },
      { count: 5, y: 144, step: 29 },
      { count: 7, y: 180, step: 25 },
      { count: 9, y: 216, step: 22 },
      { count: 9, y: 252, step: 25 },
      { count: 7, y: 288, step: 31 }
    ];
    const points = [];
    rows.forEach(row => {
      const start = 170 - ((row.count - 1) * row.step) / 2;
      for (let column = 0; column < row.count; column += 1) {
        points.push({ id: points.length + 1, x: Math.round(start + column * row.step), y: row.y });
      }
    });
    return points;
  }

  function renderTreeOrnaments(currentId = null) {
    const group = $('#treeOrnaments');
    if (!group) return;
    const done = new Set(getDoneIds());
    const markup = treePoints().map(point => {
      const isLit = done.has(point.id);
      const isCurrent = Number(currentId) === point.id;
      const task = tasks[point.id - 1];
      const stop = stopForTask(point.id);
      const state = isLit ? 'вернулась на ёлку' : 'ещё ищется';
      const label = task ? `Остановка ${point.id}, ${stop.city}: ${task.title}, игрушка ${state}` : `Остановка ${point.id}, игрушка ${state}`;
      const classes = ['tree-ornament', `hue-${point.id % 4}`, isLit ? 'is-lit' : '', isCurrent ? 'is-current' : ''].filter(Boolean).join(' ');
      return `<g class="${classes}" data-task-id="${point.id}" transform="translate(${point.x} ${point.y})" aria-hidden="true">
        <circle class="bauble-glow" r="14"/><circle class="bauble-core" r="10.5"/>
        <ellipse class="bauble-shine" cx="-3.3" cy="-4" rx="2.3" ry="3.4"/>
        <text class="bauble-number" y=".7">${point.id}</text><title>${escapeHtml(label)}</title>
      </g>`;
    }).join('');
    group.innerHTML = markup;
  }

  function updateTreeProgress(doneIds = getDoneIds()) {
    const count = Math.min(tasks.length, new Set(doneIds).size);
    const label = $('#treeProgressLabel');
    const modalCount = $('#treeModalCount');
    const caption = $('#treeProgressCaption');
    const fill = $('#treeProgressFill');
    if (label) label.textContent = `Игрушек: ${count} / ${tasks.length}`;
    if (modalCount) modalCount.textContent = String(count);
    if (caption) caption.textContent = count === 0
      ? 'Выполняй задания — и игрушки вернутся на ёлку'
      : `На ёлке уже ${count} ${russianToyWord(count)} — отличная работа!`;
    if (fill) fill.style.width = `${tasks.length ? (count / tasks.length) * 100 : 0}%`;
  }

  function openTreePopup(task = null) {
    const modal = $('#treeModal');
    if (!modal) return;
    const doneIds = getDoneIds();
    renderTreeOrnaments(task ? task.id : null);
    updateTreeProgress(doneIds);
    if (task) {
      const mascot = mascotForTask(task);
      const stop = stopForTask(task.id);
      $('#treeModalTitle').textContent = `Игрушка №${task.id} вернулась на ёлку!`;
      $('#treeModalMessage').textContent = `В городе ${stop.city} команда экспресса выполнила задание и нашла игрушку №${task.id}. ${mascot.name} зовёт всех ехать дальше — впереди новые следы Бабы Яги!`;
      $('#treeModalCharacter').hidden = false;
      $('#treeModalCharacter').innerHTML = `<span class="tree-mascot-art">${mascotMarkup(task)}</span><span class="tree-mascot-copy"><small>Проводник остановки · ${escapeHtml(stop.city)}</small><strong>${escapeHtml(mascot.name)}</strong></span>`;
      $('#treeContinueBtn').innerHTML = 'Продолжить маршрут <span aria-hidden="true">→</span>';
    } else {
      $('#treeModalTitle').textContent = 'Ёлочка находок экспресса';
      $('#treeModalMessage').textContent = doneIds.length
        ? 'За каждое выполненное задание на веточку возвращается одна праздничная игрушка.'
        : 'Выполняй задания на остановках — и найденные игрушки будут загораться на ёлочке.';
      $('#treeModalCharacter').hidden = true;
      $('#treeModalCharacter').replaceChildren();
      $('#treeContinueBtn').innerHTML = 'К маркам экспресса <span aria-hidden="true">→</span>';
    }
    openModal('treeModal');
  }

  function cardStatus(task, today, doneIds, openedIds) {
    const iso = dateForTask(task.id);
    if (!sessionFlag(DEMO_REGISTERED_KEY)) return { type: 'locked', text: 'Сначала регистрация' };
    if (!sessionFlag(DEMO_PAID_KEY)) return { type: 'locked', text: 'После оплаты' };
    if (today > ACCESS_END) return { type: 'locked', text: 'Срок доступа завершён' };
    if (iso > today) return { type: 'locked', text: `Откроется ${formatShortDate(iso)}` };
    if (doneIds.includes(task.id)) return { type: 'done', text: 'Игрушка вернулась!' };
    if (openedIds.includes(task.id)) return { type: 'visited', text: 'Задание открыто' };
    return { type: 'open', text: 'Марка открыта' };
  }

  let mapCamera = { x: 0, y: 0, w: 1800, h: 880 };
  let mapSelectedDay = null;
  let mapSetupDone = false;
  let markerLayoutCacheKey = null;
  let markerLayoutCache = null;

  function mapPoint(lat, lon) {
    const wrappedLon = lon < 0 ? lon + 360 : lon;
    return { x: (wrappedLon - 18) * 10.2, y: (83 - lat) * 19.3 };
  }

  function compactMarkerPositions(stops, separation, maxDrift) {
    const anchors = stops.map(stop => ({ ...stop.point }));
    const positions = anchors.map(point => ({ ...point }));
    for (let iteration = 0; iteration < 90; iteration += 1) {
      let moved = false;
      for (let i = 0; i < positions.length; i += 1) {
        for (let j = i + 1; j < positions.length; j += 1) {
          let dx = positions[j].x - positions[i].x;
          let dy = positions[j].y - positions[i].y;
          let distance = Math.hypot(dx, dy);
          if (distance >= separation) continue;
          if (distance < .01) { dx = ((i * 17 + j * 31) % 7) - 3; dy = ((i * 13 + j * 19) % 7) - 3; distance = Math.hypot(dx, dy) || 1; }
          const push = (separation - distance) * .24;
          const ux = dx / distance; const uy = dy / distance;
          positions[i].x -= ux * push; positions[i].y -= uy * push;
          positions[j].x += ux * push; positions[j].y += uy * push;
          moved = true;
        }
      }
      positions.forEach((point, index) => {
        const dx = point.x - anchors[index].x; const dy = point.y - anchors[index].y;
        const distance = Math.hypot(dx, dy);
        if (distance > maxDrift) { point.x = anchors[index].x + dx / distance * maxDrift; point.y = anchors[index].y + dy / distance * maxDrift; }
      });
      if (!moved) break;
    }
    return positions;
  }

  function mapStatusClass(status) {
    if (status.type === 'done') return 'is-done';
    if (status.type === 'locked') return 'is-locked';
    return 'is-open';
  }

  function renderMapStopCard(day) {
    const card = $('#mapStopCard');
    if (!card) return;
    const task = tasks.find(item => item.id === Number(day));
    const stop = route.find(item => item.day === Number(day));
    if (!task || !stop) {
      card.innerHTML = '<div class="map-stop-empty"><strong>Выбери остановку на карте</strong><span>Нажми на круг с номером — здесь появятся город, марка и краткая информация.</span></div>';
      return;
    }
    const status = cardStatus(task, getEffectiveDate(), getDoneIds(), getOpenedIds());
    const date = dateForTask(task.id);
    card.innerHTML = `<div class="map-stop-details">
      <img class="map-stop-stamp" src="${escapeHtml(stop.image)}" width="240" height="300" alt="Марка маршрута: ${escapeHtml(stop.city)}" loading="lazy">
      <div class="map-stop-copy"><small>Остановка ${String(task.id).padStart(2, '0')} · ${escapeHtml(formatLongDate(date))}</small><h3>${escapeHtml(stop.city)}</h3><p>${escapeHtml(stop.fact)}</p><span class="map-stop-status">${escapeHtml(status.text)}</span></div>
      <button class="map-open-button" id="mapOpenTaskBtn" type="button">Открыть задание <span aria-hidden="true">→</span></button>
    </div>`;
    $('#mapOpenTaskBtn').addEventListener('click', () => handleDayClick(task));
  }

  function updateMapView() {
    const svg = $('#russiaMapSvg');
    const layer = $('#russiaMapContent');
    if (!svg || !layer) return;
    svg.setAttribute('viewBox', `${mapCamera.x.toFixed(2)} ${mapCamera.y.toFixed(2)} ${mapCamera.w.toFixed(2)} ${mapCamera.h.toFixed(2)}`);
    const geography = Array.isArray(window.RUSSIA_MAP_PATHS) ? window.RUSSIA_MAP_PATHS : [];
    const grid = [];
    for (let lon = 30; lon <= 180; lon += 30) {
      const x = (lon - 18) * 10.2;
      grid.push(`<path class="map-gridline" d="M${x.toFixed(1)} 25V850"/>`);
    }
    for (let lat = 45; lat <= 80; lat += 10) {
      const y = (83 - lat) * 19.3;
      grid.push(`<path class="map-gridline" d="M20 ${y.toFixed(1)}H1780"/>`);
    }
    const land = geography.map(d => `<path class="map-land-path" fill-rule="evenodd" d="${d}"/>`).join('');
    const captions = '<text class="map-place-label" x="130" y="130">АРКТИКА</text><text class="map-place-label" x="640" y="790">СИБИРЬ</text><text class="map-place-label" x="1390" y="730">ДАЛЬНИЙ ВОСТОК</text>';
    const latitudes = window.ADVENT_CITY_COORDS || [];
    const coords = new Map(latitudes.map(item => [item.day, mapPoint(item.lat, item.lon)]));
    const stops = tasks.map(task => ({ task, stop: stopForTask(task.id), point: coords.get(task.id) })).filter(item => item.point);
    const viewport = $('#russiaMapViewport');
    const cssWidth = Math.max(280, viewport?.clientWidth || 1000);
    const unitsPerPixel = mapCamera.w / cssWidth;
    const separation = 38 * unitsPerPixel;
    const positions = compactMarkerPositions(stops, separation, 78 * unitsPerPixel);
    const leaders = [];
    const markers = [];
    stops.forEach((item, index) => {
      const { task, stop, point } = item;
      const position = positions[index];
      const status = cardStatus(task, getEffectiveDate(), getDoneIds(), getOpenedIds());
      const classes = ['map-marker', mapStatusClass(status), mapSelectedDay === task.id ? 'is-selected' : ''].filter(Boolean).join(' ');
      const radius = 16 * unitsPerPixel;
      const numberSize = 12 * unitsPerPixel;
      if (Math.hypot(position.x - point.x, position.y - point.y) > 2 * unitsPerPixel) {
        leaders.push(`<path class="map-leader" d="M${point.x.toFixed(1)} ${point.y.toFixed(1)}L${position.x.toFixed(1)} ${position.y.toFixed(1)}"/><circle class="map-city-dot" cx="${point.x.toFixed(1)}" cy="${point.y.toFixed(1)}" r="${2.6 * unitsPerPixel}"/>`);
      }
      markers.push(`<g class="${classes}" data-map-day="${task.id}" role="button" tabindex="0" aria-label="Остановка ${task.id}, ${escapeHtml(stop.city)}. ${escapeHtml(status.text)}. Выбрать остановку." transform="translate(${position.x.toFixed(1)} ${position.y.toFixed(1)})"><title>${escapeHtml(stop.city)} · ${escapeHtml(status.text)}</title><circle class="map-marker-disc" r="${radius.toFixed(1)}"/><text class="map-marker-number" style="font-size:${numberSize.toFixed(1)}px" y=".6">${String(task.id).padStart(2, '0')}</text></g>`);
    });
    layer.innerHTML = `${grid.join('')}${land}${captions}<g class="map-leaders">${leaders.join('')}</g><g class="map-markers">${markers.join('')}</g>`;
    $$('.map-marker', layer).forEach(marker => {
      const choose = () => { mapSelectedDay = Number(marker.dataset.mapDay); renderMapStopCard(mapSelectedDay); updateMapView(); };
      marker.addEventListener('click', choose);
      marker.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); choose(); } });
    });
  }

  function clampMapCamera() {
    mapCamera.w = Math.min(1800, Math.max(480, mapCamera.w));
    mapCamera.h = Math.min(880, Math.max(430, mapCamera.h));
    mapCamera.x = Math.max(0, Math.min(1800 - mapCamera.w, mapCamera.x));
    mapCamera.y = Math.max(0, Math.min(880 - mapCamera.h, mapCamera.y));
  }

  function panMap(horizontal, vertical) {
    mapCamera.x += horizontal * mapCamera.w;
    mapCamera.y += vertical * mapCamera.h;
    clampMapCamera(); updateMapView();
  }

  function zoomMap(factor) {
    const newWidth = Math.min(1800, Math.max(480, mapCamera.w * factor));
    const scale = newWidth / mapCamera.w;
    const newHeight = Math.min(880, Math.max(430, mapCamera.h * scale));
    const centerX = mapCamera.x + mapCamera.w / 2;
    const centerY = mapCamera.y + mapCamera.h / 2;
    mapCamera = { x: centerX - newWidth / 2, y: centerY - newHeight / 2, w: newWidth, h: newHeight };
    clampMapCamera(); updateMapView();
  }

  function showWholeRussia() {
    mapCamera = { x: 0, y: 0, w: 1800, h: 880 };
    updateMapView();
  }

  function setupRussiaMap() {
    if (mapSetupDone) return;
    const viewport = $('#russiaMapViewport'); const svg = $('#russiaMapSvg');
    if (!viewport || !svg) return;
    mapSetupDone = true;
    if (window.matchMedia('(max-width: 680px)').matches) mapCamera = { x: 0, y: 0, w: 760, h: 880 };
    $('#mapZoomIn')?.addEventListener('click', () => zoomMap(.78));
    $('#mapZoomOut')?.addEventListener('click', () => zoomMap(1.28));
    $('#mapReset')?.addEventListener('click', showWholeRussia);
    $('#mapPanLeft')?.addEventListener('click', () => panMap(-.52, 0));
    $('#mapPanRight')?.addEventListener('click', () => panMap(.52, 0));
    $('#mapPanUp')?.addEventListener('click', () => panMap(0, -.45));
    $('#mapPanDown')?.addEventListener('click', () => panMap(0, .45));
    viewport.addEventListener('keydown', event => {
      if (event.key === 'ArrowLeft') { event.preventDefault(); panMap(-.18, 0); }
      else if (event.key === 'ArrowRight') { event.preventDefault(); panMap(.18, 0); }
      else if (event.key === 'ArrowUp') { event.preventDefault(); panMap(0, -.18); }
      else if (event.key === 'ArrowDown') { event.preventDefault(); panMap(0, .18); }
      else if (event.key === '+' || event.key === '=') { event.preventDefault(); zoomMap(.82); }
      else if (event.key === '-') { event.preventDefault(); zoomMap(1.22); }
      else if (event.key === 'Home') { event.preventDefault(); showWholeRussia(); }
    });
    let drag = null;
    viewport.addEventListener('pointerdown', event => {
      if (event.target.closest('.map-marker')) return;
      drag = { x: event.clientX, y: event.clientY, cx: mapCamera.x, cy: mapCamera.y };
      viewport.classList.add('is-dragging'); viewport.setPointerCapture(event.pointerId);
    });
    viewport.addEventListener('pointermove', event => {
      if (!drag) return;
      const rect = viewport.getBoundingClientRect();
      mapCamera.x = drag.cx - (event.clientX - drag.x) * mapCamera.w / rect.width;
      mapCamera.y = drag.cy - (event.clientY - drag.y) * mapCamera.h / rect.height;
      clampMapCamera(); updateMapView();
    });
    const stopDrag = () => { drag = null; viewport.classList.remove('is-dragging'); };
    viewport.addEventListener('pointerup', stopDrag); viewport.addEventListener('pointercancel', stopDrag);
  }

  function renderCalendar() {
    const mapSvg = $('#russiaMapSvg');
    if (!mapSvg) return;
    setupRussiaMap();
    updateMapView();
    renderMapStopCard(mapSelectedDay);
    updateAccessState();
    updateBuyButton();
    updateTreeProgress(getDoneIds());
  }

  function handleDayClick(task) {
    if (!sessionFlag(DEMO_REGISTERED_KEY)) { openAuth('register'); return; }
    if (!sessionFlag(DEMO_PAID_KEY)) { openPurchase(); return; }
    const today = getEffectiveDate();
    if (today > ACCESS_END) { showToast('Срок доступа к календарю завершился 10 апреля 2027 года.'); return; }
    const iso = dateForTask(task.id);
    if (iso > today) {
      showToast(`Это число откроется ${formatLongDate(iso)} по московскому времени.`);
      return;
    }
    const opened = getOpenedIds();
    if (!opened.includes(task.id)) {
      saveOpenedIds([...opened, task.id]);
      renderCalendar();
    }
    if (task.id >= 1 && task.id <= 41) {
      window.location.href = `./instructions/day-${String(task.id).padStart(2, '0')}.html`;
      return;
    }
    openTask(task);
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, character => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[character]));
  }

  function openTask(task) {
    const iso = dateForTask(task.id);
    const doneIds = getDoneIds();
    const isDone = doneIds.includes(task.id);
    const mascot = mascotForTask(task);
    const stop = stopForTask(task.id);
    const content = $('#taskModalContent');
    const steps = task.steps.map(step => `<li>${escapeHtml(step)}</li>`).join('');
    content.innerHTML = `
      <div class="task-topline"><span>Остановка ${String(task.id).padStart(2, '0')}</span><span aria-hidden="true">·</span><time datetime="${iso}">${escapeHtml(formatLongDate(iso))}</time></div>
      <div class="task-route-card"><span class="task-route-label"><svg class="icon-svg" aria-hidden="true"><use href="./icons.svg#i-mail"/></svg> Марка экспресса · <strong>${escapeHtml(stop.city)}</strong></span><span class="task-route-fact">${escapeHtml(stop.fact)}</span></div>
      <div class="task-character-intro">
        <div class="task-character-avatar">${mascotMarkup(task)}<span aria-hidden="true"><svg class="icon-svg"><use href="./icons.svg#i-star"/></svg></span></div>
        <div class="task-character-copy"><small>Твой проводник</small><strong>${escapeHtml(mascot.name)}</strong><span>${escapeHtml(mascot.species)}</span></div>
      </div>
      <div class="task-character-quote"><strong>${escapeHtml(mascot.name)} говорит:</strong> «В ${escapeHtml(stop.city)} нашёлся след пропажи! Помоги мне выполнить задание — так мы вернём детям ещё кусочек праздника».</div>
      <h2 id="taskModalTitle">${escapeHtml(task.title)}</h2>
      <div class="task-meta"><span>${escapeHtml(task.category)}</span><span>${escapeHtml(task.duration)}</span><span>5+</span></div>
      <div class="task-intro"><strong>Понадобится:</strong> ${escapeHtml(task.materials)}</div>
      <h3>Как сделать</h3>
      <ol class="task-steps">${steps}</ol>
      <div class="task-example"><strong>Пример</strong>${escapeHtml(task.example)}</div>
      <div class="task-extra"><strong>Вариант попроще</strong>${escapeHtml(task.alternative)}</div>
      <div class="task-extra"><strong>Вопрос по желанию</strong>${escapeHtml(task.reflection)}</div>
      <div class="task-safety"><strong>Безопасность и помощь взрослого</strong>${escapeHtml(task.safety)}<br><br><b>Роль взрослого:</b> ${escapeHtml(task.adult)}</div>
      <div class="task-actions"><button class="task-done-btn ${isDone ? 'is-done' : ''}" type="button" id="markDoneBtn" ${isDone ? 'disabled' : ''}>${isDone ? '✓ Выполнено — игрушка на ёлке' : 'Выполнено! Вернуть игрушку на ёлку'}</button><span class="fine-print">Отметка хранится только в этом браузере в демо.</span></div>
    `;
    if (!isDone) {
      $('#markDoneBtn').addEventListener('click', () => {
        const current = getDoneIds();
        if (current.includes(task.id)) return;
        saveDoneIds([...current, task.id]);
        renderCalendar();
        closeModal('taskModal');
        openTreePopup(task);
      });
    }
    openModal('taskModal');
  }

  function updateAccessState() {
    const registered = sessionFlag(DEMO_REGISTERED_KEY);
    const paid = sessionFlag(DEMO_PAID_KEY);
    const el = $('#accessState');
    if (!el) return;
    if (!registered) el.textContent = 'Нет регистрации · задания закрыты';
    else if (!paid) el.textContent = 'Регистрация есть · ожидается оплата';
    else if (getEffectiveDate() > ACCESS_END) el.textContent = 'Срок демо-доступа завершён · 10.04.2027';
    else el.textContent = 'Демо-доступ до 10.04.2027 · даты проверяются отдельно';
  }

  function updateBuyButton() {
    const button = $('#buyBtn');
    if (!button) return;
    if (!sessionFlag(DEMO_REGISTERED_KEY)) button.textContent = 'Регистрация';
    else if (!sessionFlag(DEMO_PAID_KEY)) button.textContent = 'Оплатить сезон';
    else button.textContent = 'Статус доступа';
  }

  function openModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    lastFocused = document.activeElement;
    modal.hidden = false;
    document.body.classList.add('modal-open');
    const panel = modal.querySelector('[role="dialog"]');
    window.setTimeout(() => panel?.focus(), 0);
  }

  function closeModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.hidden = true;
    if ($$('.modal-backdrop:not([hidden])').length === 0) document.body.classList.remove('modal-open');
    if (lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus();
  }

  function showToast(text) {
    const toast = $('#toast');
    if (!toast) return;
    toast.textContent = text;
    toast.hidden = false;
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => { toast.hidden = true; }, 3500);
  }

  function openAuth(mode = 'register') {
    $('#authNotice').hidden = true;
    $('#authForm').reset();
    setAuthMode(mode);
    openModal('authModal');
  }

  function openPurchase() {
    if (!sessionFlag(DEMO_REGISTERED_KEY)) { openAuth('register'); return; }
    $('#paymentNotice').hidden = true;
    openModal('purchaseModal');
  }

  function setAuthMode(mode) {
    authMode = mode === 'login' ? 'login' : 'register';
    const isRegister = authMode === 'register';
    $('#registerTab').classList.toggle('is-active', isRegister);
    $('#signinTab').classList.toggle('is-active', !isRegister);
    $('#registerTab').setAttribute('aria-selected', String(isRegister));
    $('#signinTab').setAttribute('aria-selected', String(!isRegister));
    $('#authTitle').textContent = isRegister ? 'Создать аккаунт' : 'Войти по контакту';
    $('#authDescription').textContent = isRegister
      ? 'Аккаунт создаёт взрослый родитель или опекун. В рабочей версии контакт подтверждается одноразовым кодом.'
      : 'Укажите email или телефон, использованный при регистрации. В рабочей версии мы отправим одноразовый код.';
    $('#registrationFields').hidden = !isRegister;
    $('#nameInput').required = isRegister;
    $('#dobInput').required = isRegister;
    $('#childNameInput').required = isRegister;
    $('#adultCheck').required = isRegister;
    $('#personalDataConsent').required = isRegister;
    $('#offerAccept').required = isRegister;
    $('#authSubmitBtn').textContent = isRegister ? 'Создать аккаунт' : 'Войти';
    updateContactFields();
  }

  function updateContactFields() {
    const method = $('input[name="contactMethod"]:checked')?.value || 'email';
    const useEmail = method === 'email';
    $('#emailField').hidden = !useEmail;
    $('#phoneField').hidden = useEmail;
    $('#emailInput').required = useEmail;
    $('#phoneInput').required = !useEmail;
  }

  function calculateAge(birthDate, todayIso) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(birthDate)) return -1;
    const [by, bm, bd] = birthDate.split('-').map(Number);
    const [ty, tm, td] = todayIso.split('-').map(Number);
    let age = ty - by;
    if (tm < bm || (tm === bm && td < bd)) age -= 1;
    return age;
  }

  function setMaxAdultBirthDate() {
    const today = getDateInMoscow();
    const [year, month, day] = today.split('-').map(Number);
    const latest = new Date(Date.UTC(year - 18, month - 1, day));
    $('#dobInput').max = latest.toISOString().slice(0, 10);
  }

  function registerDemoAccount() {
    const name = $('#nameInput').value.trim();
    const childName = $('#childNameInput').value.trim();
    const birthDate = $('#dobInput').value;
    const age = calculateAge(birthDate, getDateInMoscow());
    if (!name || !childName || age < 18 || age > 120) {
      $('#authNotice').textContent = age >= 0 && age < 18
        ? 'Аккаунт предназначен взрослому родителю или опекуну. Дата рождения должна относиться к владельцу аккаунта, не к ребёнку.'
        : 'Проверьте имя и дату рождения взрослого аккаунта.';
      $('#authNotice').hidden = false;
      return;
    }
    setSessionFlag(DEMO_REGISTERED_KEY, true);
    setSessionFlag(DEMO_PAID_KEY, false);
    $('#authNotice').textContent = 'Демо-регистрация подтверждена для проверки сценария. Контакт и персональные данные не отправлялись и не сохранены.';
    $('#authNotice').hidden = false;
    renderCalendar();
    window.setTimeout(() => {
      closeModal('authModal');
      openPurchase();
    }, 900);
  }

  function loginDemoAccount() {
    if (!sessionFlag(DEMO_REGISTERED_KEY)) {
      $('#authNotice').textContent = 'В этой вкладке ещё нет демо-аккаунта. Перейдите на вкладку «Регистрация», чтобы проверить сценарий.';
      $('#authNotice').hidden = false;
      return;
    }
    $('#authNotice').textContent = 'Демо-вход выполнен. Реальный email/SMS-код пока не отправляется.';
    $('#authNotice').hidden = false;
    renderCalendar();
    if (!sessionFlag(DEMO_PAID_KEY)) window.setTimeout(() => { closeModal('authModal'); openPurchase(); }, 700);
  }

  function simulateDemoPayment() {
    if (!sessionFlag(DEMO_REGISTERED_KEY)) {
      closeModal('purchaseModal');
      openAuth('register');
      return;
    }
    setSessionFlag(DEMO_PAID_KEY, true);
    closeModal('purchaseModal');
    renderCalendar();
    showToast('Демо-оплата отмечена без списания денег. Будущие даты всё ещё закрыты.');
  }

  function setupCookies() {
    try {
      if (!sessionStorage.getItem('advent-cookie-notice-v1')) $('#cookieBanner').hidden = false;
    } catch (_error) { $('#cookieBanner').hidden = false; }
    $('#cookieDismissBtn').addEventListener('click', () => {
      try { sessionStorage.setItem('advent-cookie-notice-v1', '1'); } catch (_error) {}
      $('#cookieBanner').hidden = true;
    });
    $('#cookieSettingsBtn').addEventListener('click', () => openModal('cookiePrefsModal'));
    $('#saveCookiePrefsBtn').addEventListener('click', () => {
      try { sessionStorage.setItem('advent-cookie-notice-v1', '1'); sessionStorage.setItem('advent-analytics-consent-v1', $('#analyticsChoice').checked ? '1' : '0'); } catch (_error) {}
      $('#cookieBanner').hidden = true;
      closeModal('cookiePrefsModal');
      showToast('Настройки сохранены только в этой вкладке. Аналитика в демо не подключена.');
    });
  }

  function setupModals() {
    $$('[data-close]').forEach(button => button.addEventListener('click', () => closeModal(button.dataset.close)));
    $$('.modal-backdrop').forEach(backdrop => backdrop.addEventListener('click', event => {
      if (event.target === backdrop) closeModal(backdrop.id);
    }));
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        const visible = $$('.modal-backdrop:not([hidden])').at(-1);
        if (visible) closeModal(visible.id);
      }
    });
    $('#countdownCalendarBtn').addEventListener('click', () => {
      closeModal('countdownModal');
      $('#calendar').scrollIntoView({ behavior: 'smooth' });
    });
    $('#openCountdownBtn').addEventListener('click', () => openModal('countdownModal'));
  }

  function setupButtons() {
    $('#loginBtn').addEventListener('click', () => openAuth('login'));
    $('#heroLoginBtn').addEventListener('click', () => openAuth('login'));
    $('#buyBtn').addEventListener('click', () => {
      if (!sessionFlag(DEMO_REGISTERED_KEY)) openAuth('register');
      else if (!sessionFlag(DEMO_PAID_KEY)) openPurchase();
      else showToast('Демо-оплата отмечена. Задания открываются только в день соответствующей даты.');
    });
    $('#joinBtn').addEventListener('click', () => {
      if (!sessionFlag(DEMO_REGISTERED_KEY)) openAuth('register');
      else openPurchase();
    });
    $('#treeProgressBtn').addEventListener('click', () => openTreePopup());
    $('#treeContinueBtn').addEventListener('click', () => {
      closeModal('treeModal');
      $('#calendar').scrollIntoView({ behavior: 'smooth' });
    });
    $('#registerTab').addEventListener('click', () => { $('#authNotice').hidden = true; setAuthMode('register'); });
    $('#signinTab').addEventListener('click', () => { $('#authNotice').hidden = true; setAuthMode('login'); });
    $$('input[name="contactMethod"]').forEach(input => input.addEventListener('change', updateContactFields));

    $('#authForm').addEventListener('submit', event => {
      event.preventDefault();
      if (authMode === 'register') registerDemoAccount();
      else loginDemoAccount();
    });
    $('#demoPayBtn').addEventListener('click', simulateDemoPayment);

    $('#mobileMenuBtn').addEventListener('click', () => {
      const nav = $('.main-nav');
      const isOpen = nav.classList.toggle('is-open');
      $('#mobileMenuBtn').setAttribute('aria-expanded', String(isOpen));
      $('#mobileMenuBtn').setAttribute('aria-label', isOpen ? 'Скрыть меню' : 'Показать меню');
    });
    $$('.main-nav a').forEach(link => link.addEventListener('click', () => {
      $('.main-nav').classList.remove('is-open');
      $('#mobileMenuBtn').setAttribute('aria-expanded', 'false');
    }));
  }

  function initCountdownModal() {
    if (new URLSearchParams(location.search).get('register') === '1') {
      openAuth('register');
      return;
    }
    try {
      if (!sessionStorage.getItem('advent-countdown-seen-v2')) {
        openModal('countdownModal');
        sessionStorage.setItem('advent-countdown-seen-v2', '1');
      }
    } catch (_error) { openModal('countdownModal'); }
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }

  function setupHeroCarousel() {
    const slides = $$('.hero-slide');
    const dots = $$('.hero-dots button');
    const captions = ['Баба Яга и волшебные игрушки', 'Новогодний экспресс в пути', 'Хоровод лесных друзей'];
    if (!slides.length) return;
    let active = 0;
    const show = (index) => {
      active = (index + slides.length) % slides.length;
      slides.forEach((slide, i) => slide.classList.toggle('is-active', i === active));
      dots.forEach((dot, i) => { dot.classList.toggle('is-active', i === active); dot.setAttribute('aria-selected', String(i === active)); });
      $('#heroSlideCaption').textContent = captions[active];
    };
    $('#heroPrev').addEventListener('click', () => show(active - 1));
    $('#heroNext').addEventListener('click', () => show(active + 1));
    dots.forEach((dot, i) => dot.addEventListener('click', () => show(i)));
    let timer = window.setInterval(() => show(active + 1), 6000);
    $('.hero-art').addEventListener('mouseenter', () => { window.clearInterval(timer); });
    $('.hero-art').addEventListener('mouseleave', () => { timer = window.setInterval(() => show(active + 1), 6000); });
  }

  function init() {
    updateCountdown();
    setupHeroCarousel();
    setMaxAdultBirthDate();
    renderCalendar();
    setupModals();
    setupButtons();
    setupCookies();
    initCountdownModal();
    registerServiceWorker();
    window.addEventListener('pageshow', () => { updateCountdown(); renderCalendar(); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
