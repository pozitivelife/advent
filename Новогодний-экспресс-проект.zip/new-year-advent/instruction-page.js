(() => {
  'use strict';
  const root = document.querySelector('[data-instruction-day]');
  if (!root || !Array.isArray(window.ADVENT_TASKS) || !Array.isArray(window.ADVENT_ROUTE)) return;
  const id = Number(root.dataset.instructionDay);
  const task = window.ADVENT_TASKS.find(item => item.id === id);
  const stop = window.ADVENT_ROUTE.find(item => item.day === id);
  if (!task || !stop) return;
  const $ = (s, r = document) => r.querySelector(s);
  const escapeHtml = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const date = id <= 31 ? `${id} декабря 2026` : `${id - 31} января 2027`;
  const content = $('#instructionContent');
  const imageNames = ['garland','snowflakes','postcard','ded-moroz','snegurochka','snowman','snow-house','cardboard-ornament','winter-poem','good-moments','bird-feeder','bookmark','help-coupon','snowflake-comic','paper-chain','new-year-tale','winter-orchestra','window-pattern','five-minute-tidy','draw-music','winter-forest-shapes','paper-snow-globe','paper-story-hero','letter-ded-moroz','kind-words-snowballs','family-ritual','snowflake-search','winter-crown','festive-place-card','january-joys','story-circle','first-day-drawing','together-ticket','short-poem','home-help','fruit-pattern','winter-pantomime','story-continuation','find-winter-window','thank-you-card','home-exhibition'];
  content.innerHTML = `
    <header class="instruction-head"><span class="instruction-eyebrow">Остановка ${String(id).padStart(2,'0')} · ${escapeHtml(stop.city)}</span><h1>${escapeHtml(task.title)}</h1><div class="instruction-meta"><span>${escapeHtml(date)}</span><span>${escapeHtml(task.category)}</span><span>${escapeHtml(task.duration)}</span><span>5+</span></div></header>
    <section class="instruction-hero"><img class="instruction-image" src="./day-${String(id).padStart(2,'0')}-${imageNames[id-1]}.jpg" alt="Иллюстрация к заданию «${escapeHtml(task.title)}»" fetchpriority="high"><div class="materials"><h2>Что понадобится</h2><p>${escapeHtml(task.materials)}</p></div></section>
    <section class="steps"><h2>Как выполнить</h2><ol>${task.steps.map(step => `<li>${escapeHtml(step)}</li>`).join('')}</ol></section>
    <section class="instruction-notes"><div class="note"><strong>Пример</strong>${escapeHtml(task.example)}</div><div class="note"><strong>Можно проще</strong>${escapeHtml(task.alternative)}</div><div class="note"><strong>Вопрос по желанию</strong>${escapeHtml(task.reflection)}</div><div class="note safety-note"><strong>Безопасность и помощь взрослого</strong>${escapeHtml(task.safety)} ${escapeHtml(task.adult)}</div></section>
    <footer class="instruction-actions"><button class="action-button action-done" id="doneButton" type="button">✓ Сделано</button><button class="action-button action-postpone" id="postponeButton" type="button">Отложить</button></footer>`;

  const points = (() => {
    const rows = [{count:1,y:72,step:0},{count:3,y:108,step:35},{count:5,y:144,step:29},{count:7,y:180,step:25},{count:9,y:216,step:22},{count:9,y:252,step:25},{count:7,y:288,step:31}];
    const result=[]; rows.forEach(row=>{const start=170-((row.count-1)*row.step)/2;for(let i=0;i<row.count;i++)result.push({id:result.length+1,x:Math.round(start+i*row.step),y:row.y});}); return result;
  })();
  const doneIds = () => { try { const a=JSON.parse(localStorage.getItem('advent-demo-done-v1')||'[]'); return Array.isArray(a)?a.map(Number).filter(n=>Number.isInteger(n)&&n>=1&&n<=41):[]; } catch(_){return [];} };
  function showTree() {
    const ids = new Set(doneIds()); ids.add(id);
    $('#treeSuccessTitle').textContent = `Шарик №${id} вернулся на ёлку!`;
    $('#treeSuccessMessage').textContent = `Задание «${task.title}» выполнено в городе ${stop.city}. Отличная работа!`;
    $('#treeDoneCount').textContent = `На ёлке уже ${ids.size} из 41 игрушки`;
    $('#treeOrnaments').innerHTML = points.map(p=>{
      const lit=ids.has(p.id), current=p.id===id;
      return `<g class="tree-ornament hue-${p.id%4} ${lit?'is-lit':''} ${current?'is-current':''}" transform="translate(${p.x} ${p.y})"><circle class="bauble-glow" r="14"/><circle class="bauble-core" r="10.5"/><ellipse class="bauble-shine" cx="-3.3" cy="-4" rx="2.3" ry="3.4"/><text class="bauble-number" y=".7">${p.id}</text></g>`;
    }).join('');
    $('#treeSuccess').hidden = false;
    $('#treeSuccess').setAttribute('aria-hidden','false');
    $('#closeTreeSuccess').focus();
  }
  $('#doneButton').addEventListener('click',()=>{
    const ids = new Set(doneIds()); ids.add(id);
    try { localStorage.setItem('advent-demo-done-v1',JSON.stringify([...ids].sort((a,b)=>a-b))); } catch(_){}
    showTree();
  });
  const goBack=()=>{ window.location.href='../index.html#calendar'; };
  $('#postponeButton').addEventListener('click',goBack);
  $('#treeBackToTasks').addEventListener('click',goBack);
  $('#closeTreeSuccess').addEventListener('click',()=>{ $('#treeSuccess').hidden=true; $('#treeSuccess').setAttribute('aria-hidden','true'); $('#doneButton').focus(); });
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('#treeSuccess').hidden){$('#treeSuccess').hidden=true;$('#treeSuccess').setAttribute('aria-hidden','true');$('#doneButton').focus();}});
})();
