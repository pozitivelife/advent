const CACHE_NAME = 'new-year-express-v24';
const APP_FILES = [
  './',
  './index.html',
  './styles.css',
  './tasks.js',
  './characters.js',
  './route.js',
  './city-coordinates.js',
  './russia-outline.js',
  './app.js',
  './manifest.webmanifest',
  './icon.svg',
  './icons.svg',
  './hero-forest-friends.webp',
  './hero-slide-yaga.webp',
  './hero-slide-train.webp',
  './hero-slide-carol.webp',
  './express-night-background.webp',
  './winter-background.webp',
  './winter-snowfall.svg',
  './mascot-fox.webp',
  './instruction-pages.css',
  './instruction-page.js',
  './instructions/day-01.html',
  './instructions/day-01-garland.jpg',
  './instructions/day-02.html',
  './instructions/day-02-snowflakes.jpg',
  './instructions/day-03.html',
  './instructions/day-03-postcard.jpg',
  './instructions/day-04.html',
  './instructions/day-04-ded-moroz.jpg',
  './instructions/day-05.html',
  './instructions/day-05-snegurochka.jpg',
  './instructions/day-06.html',
  './instructions/day-06-snowman.jpg',
  './instructions/day-07.html',
  './instructions/day-07-snow-house.jpg',
  './instructions/day-08.html',
  './instructions/day-08-cardboard-ornament.jpg',
  './instructions/day-09.html',
  './instructions/day-09-winter-poem.jpg',
  './instructions/day-10.html',
  './instructions/day-10-good-moments.jpg',
  './instructions/day-11.html',
  './instructions/day-11-bird-feeder.jpg',
  './instructions/day-12.html',
  './instructions/day-12-bookmark.jpg',
  './instructions/day-13.html',
  './instructions/day-13-help-coupon.jpg',
  './instructions/day-14.html',
  './instructions/day-14-snowflake-comic.jpg',
  './instructions/day-15.html',
  './instructions/day-15-paper-chain.jpg',
  './instructions/day-16.html',
  './instructions/day-16-new-year-tale.jpg',
  './instructions/day-17.html',
  './instructions/day-17-winter-orchestra.jpg',
  './instructions/day-18.html',
  './instructions/day-18-window-pattern.jpg',
  './instructions/day-19.html',
  './instructions/day-19-five-minute-tidy.jpg',
  './instructions/day-20.html',
  './instructions/day-20-draw-music.jpg',
  './instructions/day-21.html',
  './instructions/day-21-winter-forest-shapes.jpg',
  './instructions/day-22.html',
  './instructions/day-22-paper-snow-globe.jpg',
  './instructions/day-23.html',
  './instructions/day-23-paper-story-hero.jpg',
  './instructions/day-24.html',
  './instructions/day-24-letter-ded-moroz.jpg',
  './instructions/day-25.html',
  './instructions/day-25-kind-words-snowballs.jpg',
  './instructions/day-26.html',
  './instructions/day-26-family-ritual.jpg',
  './instructions/day-27.html',
  './instructions/day-27-snowflake-search.jpg',
  './instructions/day-28.html',
  './instructions/day-28-winter-crown.jpg',
  './instructions/day-29.html',
  './instructions/day-29-festive-place-card.jpg',
  './instructions/day-30.html',
  './instructions/day-30-january-joys.jpg',
  './instructions/day-31.html',
  './instructions/day-31-story-circle.jpg',
  './instructions/day-32.html',
  './instructions/day-32-first-day-drawing.jpg',
  './instructions/day-33.html',
  './instructions/day-33-together-ticket.jpg',
  './instructions/day-34.html',
  './instructions/day-34-short-poem.jpg',
  './instructions/day-35.html',
  './instructions/day-35-home-help.jpg',
  './instructions/day-36.html',
  './instructions/day-36-fruit-pattern.jpg',
  './instructions/day-37.html',
  './instructions/day-37-winter-pantomime.jpg',
  './instructions/day-38.html',
  './instructions/day-38-story-continuation.jpg',
  './instructions/day-39.html',
  './instructions/day-39-find-winter-window.jpg',
  './instructions/day-40.html',
  './instructions/day-40-thank-you-card.jpg',
  './instructions/day-41.html',
  './instructions/day-41-home-exhibition.jpg',
  ...Array.from({ length: 41 }, (_unused, index) => `./stamps/stop-${String(index + 1).padStart(2, '0')}.svg`),
  './legal/common.css',
  './legal/privacy-policy.html',
  './legal/personal-data-consent.html',
  './legal/cookies.html',
  './legal/offer.html',
  './legal/refund.html',
  './legal/age-and-parent.html'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_FILES)));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).then(response => {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
      return response;
    }).catch(() => caches.match('./index.html')));
    return;
  }

  event.respondWith(caches.match(event.request).then(cached => {
    if (cached) return cached;
    return fetch(event.request).then(response => {
      if (response && response.ok) {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
      }
      return response;
    });
  }));
});
