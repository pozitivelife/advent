(() => {
  'use strict';

  // Original, locally-drawn winter companions. Each task has its own named character.
  const characters = [
    { name: 'Рыжуля', species: 'белочка', kind: 'squirrel' },
    { name: 'Снежинка', species: 'зайчонок', kind: 'hare' },
    { name: 'Топа', species: 'медвежонок', kind: 'bear' },
    { name: 'Феня', species: 'лисёнок', kind: 'fox' },
    { name: 'Шуршик', species: 'ёжик', kind: 'hedgehog' },
    { name: 'Синичка', species: 'синичка', kind: 'bird' },
    { name: 'Ушастик', species: 'зайка', kind: 'hare' },
    { name: 'Орех', species: 'бельчонок', kind: 'squirrel' },
    { name: 'Мята', species: 'совушка', kind: 'owl' },
    { name: 'Бублик', species: 'медвежонок', kind: 'bear' },
    { name: 'Пуговка', species: 'мышонок', kind: 'mouse' },
    { name: 'Иней', species: 'оленёнок', kind: 'reindeer' },
    { name: 'Снегирёк', species: 'снегирёк', kind: 'bird' },
    { name: 'Карамелька', species: 'косулёнок', kind: 'reindeer' },
    { name: 'Рыжик', species: 'лисёнок', kind: 'fox' },
    { name: 'Соня', species: 'совёнок', kind: 'owl' },
    { name: 'Зефирка', species: 'белочка', kind: 'squirrel' },
    { name: 'Лапка', species: 'зайчонок', kind: 'hare' },
    { name: 'Тучка', species: 'медвежонок', kind: 'bear' },
    { name: 'Шустрик', species: 'мышонок', kind: 'mouse' },
    { name: 'Ягодка', species: 'лисичка', kind: 'fox' },
    { name: 'Пёрышко', species: 'совушка', kind: 'owl' },
    { name: 'Крош', species: 'ёжик', kind: 'hedgehog' },
    { name: 'Клёпа', species: 'белочка', kind: 'squirrel' },
    { name: 'Хвостик', species: 'зайчонок', kind: 'hare' },
    { name: 'Пломбир', species: 'медвежонок', kind: 'bear' },
    { name: 'Певунья', species: 'синичка', kind: 'bird' },
    { name: 'Снежок', species: 'зайка', kind: 'hare' },
    { name: 'Травинка', species: 'оленёнок', kind: 'reindeer' },
    { name: 'Клюква', species: 'лисичка', kind: 'fox' },
    { name: 'Кнопка', species: 'мышонок', kind: 'mouse' },
    { name: 'Фырка', species: 'ёжик', kind: 'hedgehog' },
    { name: 'Лучик', species: 'белочка', kind: 'squirrel' },
    { name: 'Морошка', species: 'совушка', kind: 'owl' },
    { name: 'Хрум', species: 'медвежонок', kind: 'bear' },
    { name: 'Вьюжка', species: 'совушка', kind: 'owl' },
    { name: 'Горошек', species: 'косулёнок', kind: 'reindeer' },
    { name: 'Кедрик', species: 'бельчонок', kind: 'squirrel' },
    { name: 'Пушинка', species: 'зайчонок', kind: 'hare' },
    { name: 'Мандарин', species: 'лисёнок', kind: 'fox' },
    { name: 'Сказка', species: 'снегирёк', kind: 'bird' }
  ];

  const palettes = [
    { bg: '#ffe9cd', scarf: '#50a687', accent: '#e55b50', hair: '#8c4e37', gold: '#f0bb51' },
    { bg: '#dff2f3', scarf: '#e65d58', accent: '#4b9ab0', hair: '#7a563d', gold: '#f3c66c' },
    { bg: '#f4e2f2', scarf: '#7b71bb', accent: '#e77f9b', hair: '#6f5046', gold: '#edbd61' },
    { bg: '#e8f0d9', scarf: '#db6751', accent: '#63a275', hair: '#72503b', gold: '#efc35f' },
    { bg: '#fff0d8', scarf: '#598fb5', accent: '#e8a84b', hair: '#915c3d', gold: '#e9ba50' },
    { bg: '#e7e5f4', scarf: '#cf5660', accent: '#7b82c2', hair: '#665047', gold: '#f0c96f' },
    { bg: '#dff0e5', scarf: '#bb5b48', accent: '#58a38d', hair: '#805039', gold: '#ebbd55' },
    { bg: '#f5e5d6', scarf: '#547d9c', accent: '#d88a58', hair: '#754d38', gold: '#ecc365' }
  ];

  const animalFill = {
    squirrel: '#cf7543', hare: '#dcc6b2', bear: '#92705a', fox: '#db754c',
    bird: '#cf5a4d', mouse: '#aaa0a6', hedgehog: '#b47c57', reindeer: '#a76d49',
    goat: '#e6e0d2'
  };
  let renderCounter = 0;

  const esc = value => String(value).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));

  function commonEyes(y = 37, spread = 6, eye = '#34443d') {
    return `<circle cx="${40 - spread}" cy="${y}" r="1.7" fill="${eye}"/><circle cx="${40 + spread}" cy="${y}" r="1.7" fill="${eye}"/><circle cx="${40 - spread - 3}" cy="${y + 6}" r="3" fill="#ef9a8e" opacity=".56"/><circle cx="${40 + spread + 3}" cy="${y + 6}" r="3" fill="#ef9a8e" opacity=".56"/><path d="M36 47q4 4 8 0" fill="none" stroke="#8d5548" stroke-width="1.7" stroke-linecap="round"/>`;
  }

  function scarf(p, y = 49) {
    return `<path d="M22 ${y}q18 10 36 0l-2 8q-16 10-32 0z" fill="${p.scarf}" stroke="rgba(42,61,49,.12)" stroke-width="1"/><path d="M47 ${y + 6}l8 2-1 13-8-3z" fill="${p.scarf}"/><path d="M49 ${y + 18}l-2 3m6-3-2 3" stroke="#fff4dc" stroke-width="1.5" stroke-linecap="round" opacity=".8"/>`;
  }

  function renderKind(kind, p) {
    const fur = animalFill[kind] || '#cf7543';
    const face = (fill = fur, rx = 17, ry = 18, y = 36) => `<ellipse cx="40" cy="${y}" rx="${rx}" ry="${ry}" fill="${fill}"/>`;
    const eyes = commonEyes();
    const muzzle = `<ellipse cx="40" cy="44" rx="9" ry="6.5" fill="#fff5e6"/><path d="M38 44q2 2 4 0" fill="none" stroke="#80594c" stroke-width="1.4" stroke-linecap="round"/>`;
    switch (kind) {
      case 'santa':
        return `<path d="M20 55q-4-13 1-29 7-15 20-15 17 0 20 18l-7 3q-8-7-15-5-10 2-13 14z" fill="${p.scarf}"/><path d="M24 30q-1-18 17-20 18 1 20 18l-7-3q-10-3-18 5z" fill="#fff6e5"/><path d="M26 26q-2-17 17-20 15 0 19 14-12 5-24 3-7 0-12 3z" fill="#c84c47"/><circle cx="59" cy="12" r="6" fill="#fff8e8"/><ellipse cx="40" cy="57" rx="23" ry="17" fill="#fff8e9"/><ellipse cx="40" cy="35" rx="16" ry="17" fill="#f1c29f"/>${eyes}<ellipse cx="40" cy="44" rx="10" ry="6" fill="#fffdf6"/><path d="M31 48q9 12 18 0" fill="#fffdf6"/>`;
      case 'snowgirl':
        return `<path d="M22 33q-7-11 2-19 7-8 16-5 18-1 21 18l-6 22H25z" fill="${p.hair}"/><path d="M19 27q1-21 21-21 21 0 22 22l-8-7-14 5-15-3z" fill="${p.scarf}"/><path d="M18 25q21 6 45-4l-3 8q-22 7-41 2z" fill="#f7efdc"/><ellipse cx="40" cy="38" rx="15" ry="17" fill="#f4cfb5"/>${eyes}<path d="M25 49q-6 8-4 14m6-11q-1 9 2 15M56 48q7 8 5 14" fill="none" stroke="${p.hair}" stroke-width="3.3" stroke-linecap="round"/><path d="M34 9q6-5 12 0" stroke="${p.gold}" stroke-width="2.5" fill="none"/>`;
      case 'snowman':
        return `<ellipse cx="40" cy="55" rx="23" ry="19" fill="#fffdf5" stroke="#d5e2db" stroke-width="1.5"/><circle cx="40" cy="34" r="17" fill="#fffdf5" stroke="#d5e2db" stroke-width="1.5"/><path d="M24 20h32l-3-10H28z" fill="#456e63"/><path d="M21 21h38v5H21z" fill="${p.scarf}"/><circle cx="35" cy="34" r="1.6" fill="#35473e"/><circle cx="45" cy="34" r="1.6" fill="#35473e"/><path d="m40 37 11 4-11 3z" fill="#ed914e"/><path d="M24 46q16 7 32 0l-2 7q-14 7-28 0z" fill="${p.scarf}"/><path d="M42 57h.1m0 7h.1" stroke="#496055" stroke-width="3" stroke-linecap="round"/>`;
      case 'squirrel':
        return `<path d="M25 58C7 58 8 37 18 25 27 14 45 14 48 25c3 10-9 17-15 11-4-4-1-9 3-10-9-5-17 2-17 10 0 8 8 13 17 11" fill="${fur}" stroke="#a95135" stroke-width="2"/><circle cx="25" cy="47" r="5" fill="#f4bd69"/><ellipse cx="43" cy="56" rx="18" ry="16" fill="${p.scarf}"/><path d="M29 26 31 16 39 24m12 0 9-8-1 14" fill="${fur}"/><ellipse cx="42" cy="36" rx="17" ry="18" fill="${fur}"/><ellipse cx="43" cy="43" rx="10" ry="7" fill="#fff0d8"/>${commonEyes(35, 6)}<path d="m41 40 4 2-4 2" fill="#815045"/>`;
      case 'goat':
        return `<path d="M28 26q-3-18 7-16 7 1 4 15m8 0q-3-15 6-16 8 0 2 18" fill="none" stroke="#c39c55" stroke-width="4" stroke-linecap="round"/><path d="M22 34 11 25l4 17m43-9 11-9-4 18" fill="${fur}" stroke="#d0c7b6" stroke-width="2" stroke-linejoin="round"/><ellipse cx="40" cy="38" rx="17" ry="20" fill="${fur}"/><ellipse cx="40" cy="47" rx="10" ry="7" fill="#fff9eb"/>${commonEyes(36, 6)}<path d="M37 48q3 3 6 0" fill="none" stroke="#8d6755" stroke-width="1.5"/><path d="M30 56q10 6 20 0l-2 7q-8 5-16 0z" fill="${p.scarf}"/>`;
      case 'hare':
        return `<path d="M29 29q-10-11-6-23 3-7 9 0l7 20m4 2q-2-20 8-26 7-3 8 6l-5 24" fill="${fur}" stroke="#b69a86" stroke-width="1.6"/><path d="M29 25q-5-13-2-17 2-2 4 3l5 14m11 1q1-14 6-17 2-1 2 4l-3 16" fill="#f4a1a0"/><ellipse cx="40" cy="41" rx="17" ry="18" fill="#f2e5d6"/>${eyes}<ellipse cx="40" cy="46" rx="7" ry="5" fill="#fff8ed"/><path d="m39 44 3 1-3 2z" fill="#df8580"/><path d="M24 55q16 9 32 0l-2 7q-14 8-28 0z" fill="${p.scarf}"/>`;
      case 'bear':
        return `<circle cx="27" cy="22" r="10" fill="${fur}"/><circle cx="53" cy="22" r="10" fill="${fur}"/><circle cx="27" cy="22" r="5" fill="#e8bba5"/><circle cx="53" cy="22" r="5" fill="#e8bba5"/><ellipse cx="40" cy="39" rx="21" ry="20" fill="${fur}"/><ellipse cx="40" cy="47" rx="12" ry="8" fill="#f5e6d4"/>${commonEyes(37, 7)}<ellipse cx="40" cy="45" rx="3" ry="2.2" fill="#60493f"/><path d="M23 56q17 9 34 0l-2 8q-15 7-30 0z" fill="${p.scarf}"/>`;
      case 'fox':
        return `<path d="M23 34 16 12l20 12m8 0 20-12-7 24" fill="${fur}" stroke="#b9553c" stroke-width="1.5" stroke-linejoin="round"/><path d="m22 28-1-9 10 8m19 0 10-9-1 13" fill="#f7c2a0"/><ellipse cx="40" cy="40" rx="19" ry="19" fill="${fur}"/><path d="M25 43q4-8 15-2 11-6 15 2-7 14-15 12-9 2-15-12z" fill="#fff3df"/>${commonEyes(36, 7)}<circle cx="40" cy="44" r="2.2" fill="#62453c"/><path d="M25 55q15 9 30 0l-2 8q-13 8-26 0z" fill="${p.scarf}"/>`;
      case 'bird':
        return `<ellipse cx="40" cy="44" rx="21" ry="22" fill="${fur}"/><ellipse cx="40" cy="48" rx="13" ry="14" fill="#fff4df"/><path d="M24 34q-5-14 8-18 18-6 26 10l-6 8q-12-9-28 0z" fill="${p.scarf}"/><circle cx="34" cy="39" r="2" fill="#33493d"/><circle cx="47" cy="39" r="2" fill="#33493d"/><path d="m38 42 5 0-2.5 5z" fill="#ef9b4e"/><path d="M20 45q-9-1-10 8 9 1 14-4m42-4q9-1 10 8-9 1-14-4" fill="${fur}"/><path d="M30 63v6m18-6v6" stroke="#cc8446" stroke-width="2.5" stroke-linecap="round"/>`;
      case 'penguin':
        return `<ellipse cx="40" cy="45" rx="22" ry="25" fill="#354c57"/><ellipse cx="40" cy="50" rx="14" ry="17" fill="#fff9eb"/><path d="M21 35q0-17 19-18 19 1 19 18-8-7-19-7t-19 7z" fill="${p.scarf}"/><circle cx="34" cy="38" r="2" fill="#293d42"/><circle cx="46" cy="38" r="2" fill="#293d42"/><path d="m35 43 10 0-5 7z" fill="#e8a24c"/><path d="M20 48 10 57l12 2m38-11 10 9-12 2" fill="#354c57"/><path d="M30 66q10 5 20 0" stroke="#e6a14a" stroke-width="4" stroke-linecap="round"/>`;
      case 'owl':
        return `<path d="M22 31 18 14l17 11m8 0 17-11-4 19" fill="${fur}"/><ellipse cx="40" cy="44" rx="22" ry="22" fill="${fur}"/><ellipse cx="31" cy="39" rx="10" ry="12" fill="#fff2d8"/><ellipse cx="49" cy="39" rx="10" ry="12" fill="#fff2d8"/><circle cx="33" cy="40" r="3" fill="#40534a"/><circle cx="47" cy="40" r="3" fill="#40534a"/><path d="m37 47 6 0-3 6z" fill="#e99d4e"/><path d="M21 58q19 8 38 0l-2 7q-17 8-34 0z" fill="${p.scarf}"/><path d="M31 67 27 72m22-5 4 5" stroke="#a86a45" stroke-width="2.5" stroke-linecap="round"/>`;
      case 'mouse':
        return `<circle cx="25" cy="27" r="13" fill="#d9b8c3"/><circle cx="55" cy="27" r="13" fill="#d9b8c3"/><circle cx="25" cy="27" r="7" fill="#f4dbe0"/><circle cx="55" cy="27" r="7" fill="#f4dbe0"/><ellipse cx="40" cy="41" rx="19" ry="20" fill="${fur}"/><ellipse cx="40" cy="47" rx="10" ry="7" fill="#fff0e3"/>${commonEyes(39, 7)}<circle cx="40" cy="45" r="2.3" fill="#df8089"/><path d="M25 46 14 43m12 8-11 3m40-8 11-3m-12 8 11 3" stroke="#8b7775" stroke-width="1.2" stroke-linecap="round"/><path d="M24 57q16 8 32 0l-2 7q-14 7-28 0z" fill="${p.scarf}"/>`;
      case 'reindeer':
        return `<path d="M28 26Q14 19 20 8m7 12Q27 9 35 7m17 20Q66 20 60 8m-7 12Q53 9 45 7" fill="none" stroke="#9a704b" stroke-width="3.5" stroke-linecap="round"/><path d="M22 30 14 24l4 17m40-11 8-6-4 18" fill="${fur}"/><ellipse cx="40" cy="40" rx="18" ry="20" fill="${fur}"/><ellipse cx="40" cy="47" rx="10" ry="7" fill="#f2ddc3"/>${commonEyes(38, 6)}<circle cx="40" cy="46" r="3.5" fill="#d8594d"/><path d="M24 57q16 8 32 0l-2 7q-14 7-28 0z" fill="${p.scarf}"/>`;
      case 'hedgehog':
        return `<path d="M20 49 15 34l9 4 0-16 10 12 7-15 6 15 12-10-3 17 9-5-4 19H23z" fill="#8b6046" stroke="#76513e" stroke-width="1.4" stroke-linejoin="round"/><ellipse cx="41" cy="46" rx="18" ry="17" fill="#d9aa7e"/><ellipse cx="48" cy="48" rx="10" ry="7" fill="#f7e5cd"/><circle cx="37" cy="42" r="1.8" fill="#493d38"/><circle cx="49" cy="43" r="1.8" fill="#493d38"/><circle cx="54" cy="49" r="2.2" fill="#59433d"/><path d="M28 57q13 8 27 0l-2 7q-12 6-23 0z" fill="${p.scarf}"/>`;
      default:
        return `<circle cx="40" cy="39" r="20" fill="${fur}"/>${eyes}`;
    }
  }

  function getMascot(id) {
    const mascot = characters[Number(id) - 1];
    if (!mascot) return { name: 'Снежок', species: 'снеговичок', kind: 'snowman' };
    return mascot;
  }

  function renderMascot(id) {
    const n = Math.max(1, Number(id) || 1);
    const m = getMascot(n);
    const p = palettes[(n - 1) % palettes.length];
    const uniqueId = `mascot-${n}-${++renderCounter}`;
    const confettiX = 13 + (n * 7 % 52);
    const confettiY = 14 + (n * 11 % 48);
    return `<svg class="mascot-svg" viewBox="0 0 80 80" focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
      <defs><linearGradient id="${uniqueId}-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fffdf7"/><stop offset="1" stop-color="${p.bg}"/></linearGradient></defs>
      <rect x="2" y="2" width="76" height="76" rx="25" fill="url(#${uniqueId}-bg)"/>
      <circle cx="${confettiX}" cy="${confettiY}" r="2.1" fill="${p.gold}" opacity=".8"/>
      <path d="M${confettiX + 8} ${confettiY + 3}l1.5 3 3 .5-2.2 2.2.5 3-2.8-1.5-2.8 1.5.5-3-2.2-2.2 3-.5z" fill="#fffdf7" opacity=".85"/>
      ${renderKind(m.kind, p)}
    </svg>`;
  }

  window.getAdventMascot = getMascot;
  window.renderAdventMascot = renderMascot;
})();
